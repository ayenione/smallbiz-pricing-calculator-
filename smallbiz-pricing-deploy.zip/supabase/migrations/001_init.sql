-- ============================================================================
-- SmallBiz Job Profit & Pricing Calculator — Supabase Postgres Schema
-- Multi-tenant auth isolation (RLS) + atomic 2-quotes/month freemium quota
-- + one-time lifetime unlock via signed Lemon Squeezy webhook.
-- ============================================================================

create extension if not exists pgcrypto;

-- 1. User Profiles (1:1 with auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  plan text not null default 'free' check (plan in ('free', 'lifetime')),
  unlocked_at timestamptz,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2. Saved Jobs (quotes + completed actuals, strictly scoped to user_id)
create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'quoted' check (status in ('quoted', 'completed')),
  customer_name text not null,
  service_type text not null default '',
  notes text not null default '',
  snapshot jsonb not null,
  estimate jsonb not null,
  actual jsonb,
  created_at date not null default current_date,
  completed_date date,
  updated_at timestamptz not null default now()
);

create index if not exists idx_jobs_user_created on public.jobs (user_id, created_at desc);

-- 3. Immutable Monthly Quote Usage Counter
-- Deleting a job does NOT decrement quotes_created, closing the delete/recreate loophole.
create table if not exists public.monthly_quote_usage (
  user_id uuid not null references public.profiles(id) on delete cascade,
  year_month text not null check (year_month ~ '^\d{4}-\d{2}$'),
  quotes_created integer not null default 0 check (quotes_created >= 0),
  updated_at timestamptz not null default now(),
  primary key (user_id, year_month)
);

-- 4. Payment Receipts (written only by service_role in verified webhook)
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider text not null default 'lemonsqueezy',
  provider_order_id text not null unique,
  amount_cents integer not null check (amount_cents >= 0),
  currency text not null default 'USD',
  status text not null default 'paid',
  created_at timestamptz not null default now()
);

-- ============================================================================
-- Triggers: Auto-create profile on signup & block client self-upgrade
-- ============================================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, coalesce(new.email, ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Prevent authenticated users from modifying plan or unlocked_at directly
create or replace function public.guard_profile_plan_fields()
returns trigger
language plpgsql
as $$
begin
  if current_setting('request.jwt.claim.role', true) = 'authenticated' then
    if new.plan is distinct from old.plan or new.unlocked_at is distinct from old.unlocked_at then
      raise exception 'Forbidden: plan status can only be updated by verified payment webhook';
    end if;
  end if;
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_guard_profile_plan on public.profiles;
create trigger trg_guard_profile_plan
  before update on public.profiles
  for each row execute function public.guard_profile_plan_fields();

-- ============================================================================
-- Row-Level Security (RLS) Policies
-- ============================================================================

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;
alter table public.monthly_quote_usage enable row level security;
alter table public.payments enable row level security;

-- Profiles: users can view & update their own settings only
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);

-- Jobs: users can select, update, delete ONLY their own jobs.
-- Direct INSERT is omitted on purpose so new jobs MUST go through create_job_with_quota().
drop policy if exists "jobs_select_own" on public.jobs;
create policy "jobs_select_own"
  on public.jobs for select
  using (auth.uid() = user_id);

drop policy if exists "jobs_update_own" on public.jobs;
create policy "jobs_update_own"
  on public.jobs for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "jobs_delete_own" on public.jobs;
create policy "jobs_delete_own"
  on public.jobs for delete
  using (auth.uid() = user_id);

-- Usage: users can read their own monthly quota counter
drop policy if exists "usage_select_own" on public.monthly_quote_usage;
create policy "usage_select_own"
  on public.monthly_quote_usage for select
  using (auth.uid() = user_id);

-- Payments: users can read their own receipts
drop policy if exists "payments_select_own" on public.payments;
create policy "payments_select_own"
  on public.payments for select
  using (auth.uid() = user_id);

-- ============================================================================
-- Atomic RPC: Create a New Job with Strict Monthly Quota Enforcement
-- ============================================================================

create or replace function public.create_job_with_quota(
  p_customer_name text,
  p_service_type text,
  p_notes text,
  p_status text,
  p_created_at date,
  p_completed_date date,
  p_snapshot jsonb,
  p_estimate jsonb,
  p_actual jsonb default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_plan text;
  v_month text := to_char(timezone('UTC', now()), 'YYYY-MM');
  v_used integer := 0;
  v_limit integer := 2;
  v_job public.jobs;
begin
  if v_uid is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  -- Lock profile row to serialize concurrent create requests from the same user
  select plan into v_plan
  from public.profiles
  where id = v_uid
  for update;

  if v_plan is null then
    raise exception 'PROFILE_NOT_FOUND';
  end if;

  select quotes_created into v_used
  from public.monthly_quote_usage
  where user_id = v_uid and year_month = v_month;

  v_used := coalesce(v_used, 0);

  if v_plan <> 'lifetime' and v_used >= v_limit then
    raise exception 'QUOTA_EXCEEDED';
  end if;

  insert into public.jobs (
    user_id,
    status,
    customer_name,
    service_type,
    notes,
    created_at,
    completed_date,
    snapshot,
    estimate,
    actual
  )
  values (
    v_uid,
    case when p_status = 'completed' and p_actual is not null then 'completed' else 'quoted' end,
    coalesce(nullif(trim(p_customer_name), ''), 'Untitled job'),
    coalesce(trim(p_service_type), ''),
    coalesce(p_notes, ''),
    coalesce(p_created_at, current_date),
    case when p_status = 'completed' and p_actual is not null then coalesce(p_completed_date, current_date) else null end,
    p_snapshot,
    p_estimate,
    case when p_status = 'completed' then p_actual else null end
  )
  returning * into v_job;

  insert into public.monthly_quote_usage (user_id, year_month, quotes_created, updated_at)
  values (v_uid, v_month, 1, now())
  on conflict (user_id, year_month)
  do update set
    quotes_created = public.monthly_quote_usage.quotes_created + 1,
    updated_at = now()
  returning quotes_created into v_used;

  return jsonb_build_object(
    'job', to_jsonb(v_job),
    'usage', jsonb_build_object(
      'year_month', v_month,
      'quotes_created', v_used,
      'limit', v_limit
    )
  );
end;
$$;

grant execute on function public.create_job_with_quota(text, text, text, text, date, date, jsonb, jsonb, jsonb) to authenticated;
