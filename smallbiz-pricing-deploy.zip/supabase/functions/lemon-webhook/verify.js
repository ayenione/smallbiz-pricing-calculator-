/**
 * Shared Lemon Squeezy webhook signature verification & payload parsing helpers
 * (Standard Web Crypto API — works identically in Deno Edge Functions and Node 22).
 */

export async function computeHmacSha256Hex(secret, rawBody) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sigBuf = await crypto.subtle.sign('HMAC', key, enc.encode(rawBody));
  return Array.from(new Uint8Array(sigBuf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Constant-time string comparison to avoid timing attacks on HMAC verification.
 */
export function timingSafeEqualHex(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length || a.length === 0) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

export async function verifyLemonSignature(secret, rawBody, signatureHeader) {
  if (!secret || !signatureHeader || typeof rawBody !== 'string') return false;
  const expected = await computeHmacSha256Hex(secret, rawBody);
  return timingSafeEqualHex(expected, signatureHeader.trim().toLowerCase());
}

/**
 * Extract validated unlock details from a Lemon Squeezy order_created webhook payload.
 */
export function parseLemonOrderEvent(payload) {
  const eventName = payload?.meta?.event_name;
  if (eventName !== 'order_created') {
    return { ignored: true, reason: `Unsupported event: ${eventName || 'unknown'}` };
  }

  const attrs = payload?.data?.attributes || {};
  const status = String(attrs.status || '').toLowerCase();
  if (status !== 'paid') {
    return { ignored: true, reason: `Order status is not paid (${status})` };
  }

  const userId = payload?.meta?.custom_data?.user_id;
  if (!userId || typeof userId !== 'string') {
    return { error: 'Missing meta.custom_data.user_id in webhook payload' };
  }

  const orderId = String(payload?.data?.id || attrs.order_number || '');
  if (!orderId) {
    return { error: 'Missing order ID in webhook payload' };
  }

  return {
    ignored: false,
    userId,
    orderId,
    amountCents: Number(attrs.total ?? 0),
    currency: String(attrs.currency || 'USD').toUpperCase(),
    status,
  };
}
