// Supabase Edge Function: Lemon Squeezy One-Time Lifetime Unlock Webhook
// Deploy with: supabase functions deploy lemon-webhook --no-verify-jwt
// Required secrets:
//   LEMON_WEBHOOK_SECRET   (from Lemon Squeezy -> Settings -> Webhooks)
//   SUPABASE_URL           (provided automatically by Supabase)
//   SUPABASE_SERVICE_ROLE_KEY (provided automatically by Supabase)

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { verifyLemonSignature, parseLemonOrderEvent } from './verify.js';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  const secret = Deno.env.get('LEMON_WEBHOOK_SECRET') || '';
  const signature = req.headers.get('x-signature') || '';
  const rawBody = await req.text();

  const valid = await verifyLemonSignature(secret, rawBody, signature);
  if (!valid) {
    return new Response(JSON.stringify({ error: 'Invalid webhook signature' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  let payload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const parsed = parseLemonOrderEvent(payload);
  if (parsed.ignored) {
    return new Response(JSON.stringify({ ok: true, ignored: true, reason: parsed.reason }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  }
  if (parsed.error) {
    return new Response(JSON.stringify({ error: parsed.error }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  // 1. Idempotent payment insert (duplicate webhook deliveries safely no-op)
  const { error: payErr } = await supabase.from('payments').upsert(
    {
      user_id: parsed.userId,
      provider: 'lemonsqueezy',
      provider_order_id: parsed.orderId,
      amount_cents: parsed.amountCents,
      currency: parsed.currency,
      status: parsed.status,
    },
    { onConflict: 'provider_order_id', ignoreDuplicates: true }
  );

  if (payErr) {
    return new Response(JSON.stringify({ error: payErr.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // 2. Unlock lifetime plan on the user's profile
  const { error: profErr } = await supabase
    .from('profiles')
    .update({
      plan: 'lifetime',
      unlocked_at: new Date().toISOString(),
    })
    .eq('id', parsed.userId);

  if (profErr) {
    return new Response(JSON.stringify({ error: profErr.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  return new Response(JSON.stringify({ ok: true, unlockedUserId: parsed.userId }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  });
});
