import assert from 'node:assert/strict';
import { createLocalMultiUserProvider } from '../js/providers/localMultiUserProvider.js';
import { DEFAULT_SETTINGS } from '../js/demoData.js';

function makeMemoryStorage() {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k),
  };
}

function makeDraft(customerName, serviceType, quotedPrice = 300) {
  return {
    createdAt: '2026-11-10',
    completedDate: null,
    status: 'quoted',
    customerName,
    serviceType,
    notes: '',
    snapshot: {
      targetMargin: 0.4,
      taxRate: 0,
      currency: 'USD',
      distanceUnit: 'km',
      defaultLabourRate: 30,
      defaultTravelRate: 0.6,
      defaultOverhead: 20,
    },
    estimate: {
      quotedPrice,
      labourHours: 4,
      labourRate: 30,
      materials: 20,
      travelDistance: 10,
      travelRate: 0.6,
      equipment: 0,
      subcontractor: 0,
      otherDirect: 0,
      overhead: 20,
    },
    actual: null,
  };
}

const mem = makeMemoryStorage();
let currentDate = new Date('2026-11-15T12:00:00Z');
const svc = createLocalMultiUserProvider({
  storage: mem,
  nowFn: () => currentDate,
  freeMonthlyLimit: 2,
});

// 1. User A (Landscaper) signs up and customizes settings
const userA = await svc.signUp({ email: 'landscaper@example.com', password: 'password123' });
assert.ok(userA.user.id);

await svc.saveSettings({
  ...DEFAULT_SETTINGS,
  labourRate: 45,
  currency: 'CAD',
  businessName: 'GreenThumb Landscaping',
});

let dataA = await svc.loadAccountData();
assert.equal(dataA.profile.plan, 'free');
assert.equal(dataA.profile.settings.labourRate, 45);
assert.equal(dataA.profile.settings.currency, 'CAD');
assert.equal(dataA.usage.quotesCreated, 0);
assert.equal(dataA.jobs.length, 0);

// 2. User A saves 2 quotes in Nov 2026 -> succeeds (2/2)
const q1 = await svc.createJobWithQuota(makeDraft('Oak Lawn Care', 'Landscaping', 320));
assert.equal(q1.usage.quotesCreated, 1);

const q2 = await svc.createJobWithQuota(makeDraft('Pine Hedge Trim', 'Landscaping', 280));
assert.equal(q2.usage.quotesCreated, 2);

// 3. Editing an existing quote & recording actuals at 2/2 is ALWAYS allowed!
const updatedQ1 = await svc.updateJob({
  ...q1.job,
  status: 'completed',
  completedDate: '2026-11-16',
  actual: {
    actualPrice: 320,
    labourHours: 4.5,
    labourRate: 30,
    materials: 25,
    travelDistance: 10,
    travelRate: 0.6,
    equipment: 0,
    subcontractor: 0,
    otherDirect: 0,
    overhead: 20,
  },
});
assert.equal(updatedQ1.status, 'completed');

// 4. Attempting a 3rd new quote in Nov 2026 MUST fail with QUOTA_EXCEEDED
await assert.rejects(
  () => svc.createJobWithQuota(makeDraft('Maple Mulching', 'Landscaping', 450)),
  (err) => err.code === 'QUOTA_EXCEEDED'
);

// 5. Deleting Quote #2 MUST NOT refund the monthly quota (prevents delete-and-recreate loophole!)
await svc.deleteJob(q2.job.id);
await assert.rejects(
  () => svc.createJobWithQuota(makeDraft('Birch Cleanup', 'Landscaping', 210)),
  (err) => err.code === 'QUOTA_EXCEEDED'
);

// 6. User A logs out -> User B (Cleaner) signs up -> complete tenant isolation!
await svc.signOut();
const sessionAfterLogout = await svc.getSession();
assert.equal(sessionAfterLogout.user, null);

await svc.signUp({ email: 'cleaner@example.com', password: 'password456' });
const dataB = await svc.loadAccountData();
assert.equal(dataB.jobs.length, 0, 'User B must see 0 of User A jobs');
assert.equal(dataB.profile.settings.labourRate, 30, 'User B must have clean default settings');
assert.equal(dataB.profile.settings.currency, 'USD');
assert.equal(dataB.usage.quotesCreated, 0, 'User B must start with 0/2 monthly quotes');

const bq1 = await svc.createJobWithQuota(makeDraft('Miller House Deep Clean', 'House cleaning', 240));
assert.equal(bq1.usage.quotesCreated, 1);

// 7. Month rollover (Nov -> Dec) resets User A's free quota cleanly!
await svc.signOut();
await svc.signIn({ email: 'landscaper@example.com', password: 'password123' });

// Verify User A still only sees their own 1 remaining job (NOT User B's job!)
dataA = await svc.loadAccountData();
assert.equal(dataA.jobs.length, 1);
assert.equal(dataA.jobs[0].customerName, 'Oak Lawn Care');

// Advance clock to December 2026
currentDate = new Date('2026-12-01T00:05:00Z');
const q3Dec = await svc.createJobWithQuota(makeDraft('Winter Snow Clear', 'Landscaping', 400));
assert.equal(q3Dec.usage.yearMonth, '2026-12');
assert.equal(q3Dec.usage.quotesCreated, 1);

const q4Dec = await svc.createJobWithQuota(makeDraft('Holiday Lights', 'Landscaping', 520));
assert.equal(q4Dec.usage.quotesCreated, 2);

await assert.rejects(
  () => svc.createJobWithQuota(makeDraft('Blocked 3rd Dec Quote', 'Landscaping', 190)),
  (err) => err.code === 'QUOTA_EXCEEDED'
);

// 8. User A unlocks Lifetime Pro -> 3rd, 4th, 5th quotes succeed immediately!
await svc.unlockLifetimeTest();
const q5Unlimited = await svc.createJobWithQuota(makeDraft('Unlimited Quote 1', 'Landscaping', 600));
assert.equal(q5Unlimited.job.customerName, 'Unlimited Quote 1');
const q6Unlimited = await svc.createJobWithQuota(makeDraft('Unlimited Quote 2', 'Landscaping', 650));
assert.equal(q6Unlimited.job.customerName, 'Unlimited Quote 2');

// 9. Verify User B is STILL on 'free' plan (unlocking User A never leaks to User B!)
await svc.signOut();
await svc.signIn({ email: 'cleaner@example.com', password: 'password456' });
const dataBAfter = await svc.loadAccountData();
assert.equal(dataBAfter.profile.plan, 'free');
assert.equal(dataBAfter.jobs.length, 1);
assert.equal(dataBAfter.jobs[0].customerName, 'Miller House Deep Clean');

// 10. Wrong password rejected
await svc.signOut();
await assert.rejects(
  () => svc.signIn({ email: 'cleaner@example.com', password: 'wrongpassword' }),
  /Invalid email or password/
);

console.log('All multi-tenant isolation, monthly quota, rollover & lifetime unlock tests passed!');
