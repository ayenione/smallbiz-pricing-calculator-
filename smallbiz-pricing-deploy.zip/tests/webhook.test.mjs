import assert from 'node:assert/strict';
import {
  computeHmacSha256Hex,
  verifyLemonSignature,
  parseLemonOrderEvent,
} from '../supabase/functions/lemon-webhook/verify.js';

const SECRET = 'whsec_test_smallbiz_secret_12345';

const validPayload = {
  meta: {
    event_name: 'order_created',
    custom_data: {
      user_id: '11111111-2222-3333-4444-555555555555',
    },
  },
  data: {
    id: 'ls_order_987654',
    attributes: {
      status: 'paid',
      total: 2900,
      currency: 'USD',
    },
  },
};

const rawBody = JSON.stringify(validPayload);
const validSig = await computeHmacSha256Hex(SECRET, rawBody);

// 1. Valid signature passes
assert.equal(await verifyLemonSignature(SECRET, rawBody, validSig), true);
assert.equal(await verifyLemonSignature(SECRET, rawBody, validSig.toUpperCase()), true);

// 2. Tampered body fails
assert.equal(await verifyLemonSignature(SECRET, rawBody.replace('2900', '100'), validSig), false);

// 3. Wrong secret fails
assert.equal(await verifyLemonSignature('wrong_secret', rawBody, validSig), false);

// 4. Missing/empty signature fails
assert.equal(await verifyLemonSignature(SECRET, rawBody, ''), false);
assert.equal(await verifyLemonSignature(SECRET, rawBody, null), false);

// 5. Payload parsing: valid paid order_created
const parsed = parseLemonOrderEvent(validPayload);
assert.equal(parsed.ignored, false);
assert.equal(parsed.userId, '11111111-2222-3333-4444-555555555555');
assert.equal(parsed.orderId, 'ls_order_987654');
assert.equal(parsed.amountCents, 2900);
assert.equal(parsed.currency, 'USD');

// 6. Non-order events safely ignored
const ignoredEvt = parseLemonOrderEvent({ meta: { event_name: 'subscription_created' }, data: {} });
assert.equal(ignoredEvt.ignored, true);

// 7. Unpaid order safely ignored
const unpaidEvt = parseLemonOrderEvent({
  meta: { event_name: 'order_created', custom_data: { user_id: 'abc' } },
  data: { id: 'o1', attributes: { status: 'pending' } },
});
assert.equal(unpaidEvt.ignored, true);

// 8. Missing user_id returns explicit error
const noUser = parseLemonOrderEvent({
  meta: { event_name: 'order_created', custom_data: {} },
  data: { id: 'o2', attributes: { status: 'paid' } },
});
assert.ok(noUser.error && noUser.error.includes('user_id'));

console.log('All Lemon Squeezy webhook HMAC & payload tests passed!');
