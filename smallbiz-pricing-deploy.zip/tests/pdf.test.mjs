import assert from 'node:assert/strict';
import { buildCustomerQuotePdfBytes, buildQuotePdfFilename } from '../js/pdfQuote.js';

const sampleJob = {
  customerName: 'Birch Hedge Trim',
  serviceType: 'Landscaping',
  createdAt: '2026-11-24',
  notes: 'Trim front and rear hedges.\nHaul away all clippings.',
  snapshot: { currency: 'CAD', targetMargin: 0.4, taxRate: 0.05 },
  estimate: {
    quotedPrice: 260,
    labourHours: 2.5,
    labourRate: 45,
    materials: 0,
    travelDistance: 0,
    travelRate: 0.6,
    equipment: 0,
    subcontractor: 0,
    otherDirect: 0,
    overhead: 20,
  },
};

const settings = {
  businessName: 'GreenYard Landscaping',
  businessPhone: '(604) 555-0192',
  businessEmail: 'hello@greenyard.ca',
  quoteValidity: 'Valid for 30 days',
  quoteFooterNote: 'Thank you for your business.',
};

const bytes = buildCustomerQuotePdfBytes(sampleJob, settings);
assert.ok(bytes instanceof Uint8Array && bytes.length > 800, 'PDF bytes should be non-empty');

const text = new TextDecoder('latin1').decode(bytes);
assert.ok(text.startsWith('%PDF-1.4\n'), 'Must start with %PDF-1.4 header');
assert.ok(text.includes('xref\n0 7\n'), 'Must contain valid 7-entry xref table');
assert.ok(text.trimEnd().endsWith('%%EOF'), 'Must end with %%EOF');

// Customer-facing content present
assert.ok(text.includes('GreenYard Landscaping'));
assert.ok(text.includes('Birch Hedge Trim'));
assert.ok(text.includes('CUSTOMER QUOTE'));
assert.ok(text.includes('260.00'));
assert.ok(text.includes('273.00'), 'Tax-inclusive total at 5% should be 273.00');

// Internal sensitive fields MUST NEVER appear in the customer PDF
assert.ok(!text.toLowerCase().includes('margin'), 'Internal margin must not leak into PDF');
assert.ok(!text.toLowerCase().includes('overhead'), 'Internal overhead must not leak into PDF');
assert.ok(!text.includes('132.50'), 'Internal total cost must not leak into PDF');

// Verify xref byte offsets match actual object start positions
const xrefStartMatch = text.match(/startxref\n(\d+)\n%%EOF/);
assert.ok(xrefStartMatch, 'Missing startxref');
const xrefPos = Number(xrefStartMatch[1]);
assert.equal(text.slice(xrefPos, xrefPos + 4), 'xref', 'startxref offset must point exactly to xref');

const filename = buildQuotePdfFilename(sampleJob);
assert.ok(filename.startsWith('quote-birch-hedge-trim-') && filename.endsWith('.pdf'));

// Also test EUR (€) and GBP (£) encoding
const eurBytes = buildCustomerQuotePdfBytes(
  { ...sampleJob, snapshot: { currency: 'EUR', targetMargin: 0.4, taxRate: 0 } },
  settings
);
const eurText = new TextDecoder('latin1').decode(eurBytes);
assert.ok(eurText.includes('\\200'), 'Euro symbol should be WinAnsi octal encoded as \\200');

console.log('All Customer Quote PDF generation & security tests passed!');
