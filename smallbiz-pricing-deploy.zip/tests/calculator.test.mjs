import assert from 'node:assert/strict';
import {
  calculateEstimate,
  calculateActuals,
  calculateLogSummary,
  clampMargin,
  round2,
  ceil2,
  JOB_STATUS_RESULT,
} from '../js/calculator.js';
import { formatCurrency } from '../js/format.js';
import { createDemoJobs } from '../js/demoData.js';
import { exportJobsCSV, normalizeState, parseBackupJSON } from '../js/storage.js';

// 1. Verify Smith driveway estimate (matches workbook & product visuals)
{
  const demo = createDemoJobs();
  const smith = demo[0];
  const est = calculateEstimate(smith.estimate, smith.snapshot);

  assert.equal(est.totalCost, 192.0);
  assert.equal(est.recommendedPrice, 320.0);
  assert.equal(est.expectedProfit, 158.0);
  assert.equal(Number((est.expectedMargin * 100).toFixed(1)), 45.1);
  assert.equal(est.diffFromRecommended, 30.0);
  assert.equal(est.breakEvenPrice, 192.0);
  assert.equal(est.quotedPriceInclTax, 350.0);
  assert.equal(est.resultCode, JOB_STATUS_RESULT.ON_TARGET);
  assert.equal(est.resultLabel, 'Meets target');
}

// 2. Verify Smith driveway actuals & variance (matches JOB RESULTS tab)
{
  const demo = createDemoJobs();
  const smith = demo[0];
  const act = calculateActuals(smith.actual, smith.estimate, smith.snapshot);

  assert.equal(act.actualTotalCost, 234.4);
  assert.equal(act.actualProfit, 115.6);
  assert.equal(Number((act.actualMargin * 100).toFixed(1)), 33.0);
  assert.equal(act.priceVsRecommended, 30.0);
  assert.equal(act.profitVariance, -42.4);
  assert.equal(act.resultCode, JOB_STATUS_RESULT.BELOW_TARGET);
}

// 3. Verify Job Log summary aggregates across all 3 completed demo jobs
{
  const demo = createDemoJobs();
  const summary = calculateLogSummary(demo);

  assert.equal(summary.completedCount, 3);
  assert.equal(summary.quotedCount, 1);
  assert.equal(summary.hasMixedCurrencies, false);
  assert.equal(summary.displayCurrency, 'USD');
  assert.equal(summary.revenue, 1075.0);
  assert.equal(summary.totalCost, 646.4);
  assert.equal(summary.totalProfit, 428.6);
  assert.equal(summary.lossMakingCount, 0);
  assert.equal(summary.onTargetCount, 2);
  assert.equal(summary.belowTargetCount, 1);
}

// 4. Verify START HERE worked example: $150 cost @ 40% margin => $250 required price, $100 profit
{
  const est = calculateEstimate(
    { labourHours: 5, labourRate: 30, quotedPrice: 250 },
    { targetMargin: 0.4, taxRate: 0.1 }
  );
  assert.equal(est.totalCost, 150.0);
  assert.equal(est.recommendedPrice, 250.0);
  assert.equal(est.expectedProfit, 100.0);
  assert.equal(Number((est.expectedMargin * 100).toFixed(1)), 40.0);
  assert.equal(est.quotedPriceInclTax, 275.0);
  assert.equal(est.resultCode, JOB_STATUS_RESULT.ON_TARGET);
}

// 5. Sign-symmetric round2, no -0, and exact ceil2 behavior
{
  assert.equal(round2(1.005), 1.01);
  assert.equal(round2(-1.005), -1.01);
  assert.equal(Object.is(round2(-0.004), -0), false);
  assert.equal(formatCurrency(-0.001, 'USD'), '$0.00');
  assert.equal(ceil2(320.0), 320.0);
  assert.equal(ceil2(192 / 0.6), 320.0);
  assert.equal(ceil2(170 / 0.6), 283.34);
  assert.equal(ceil2(1 / 0.95), 1.06);
}

// 6. Exhaustive fuzz test: "Use Recommended" -> record identical actuals ALWAYS meets target!
{
  for (let cost = 1; cost <= 500; cost += 3) {
    for (let m = 0; m <= 95; m += 5) {
      const snap = { targetMargin: m / 100, taxRate: 0 };
      const est0 = calculateEstimate({ materials: cost }, snap);
      const est1 = calculateEstimate({ materials: cost, quotedPrice: est0.recommendedPrice }, snap);
      assert.equal(
        est1.resultCode,
        JOB_STATUS_RESULT.ON_TARGET,
        `Quote Use Recommended failed for cost=${cost}, margin=${m}% (rec=${est0.recommendedPrice})`
      );
      const act1 = calculateActuals(
        { materials: cost, actualPrice: est0.recommendedPrice },
        { materials: cost, quotedPrice: est0.recommendedPrice },
        snap
      );
      assert.equal(
        act1.resultCode,
        JOB_STATUS_RESULT.ON_TARGET,
        `Actuals Use Recommended failed for cost=${cost}, margin=${m}% (rec=${est0.recommendedPrice})`
      );
    }
  }
}

// 7. Edge cases: negative inputs, zero/zero, blank actualPrice totalCost, invalid margin >= 1
{
  const negEst = calculateEstimate({ materials: 100, quotedPrice: -50 }, { targetMargin: 0.4 });
  assert.equal(negEst.hasNegativeInput, true);
  assert.equal(negEst.resultCode, JOB_STATUS_RESULT.CHECK_INPUTS);
  assert.equal(negEst.expectedProfit, null);

  const negCost = calculateEstimate({ materials: -25, quotedPrice: 100 }, { targetMargin: 0.4 });
  assert.equal(negCost.hasNegativeInput, true);
  assert.equal(negCost.resultCode, JOB_STATUS_RESULT.CHECK_INPUTS);

  const zeroZero = calculateEstimate({ materials: 0, quotedPrice: 0 }, { targetMargin: 0.4 });
  assert.equal(zeroZero.resultCode, JOB_STATUS_RESULT.CHECK_INPUTS);

  const zeroActZeroCost = calculateActuals(
    { actualPrice: 0, materials: 0 },
    { quotedPrice: 0, materials: 0 },
    { targetMargin: 0.4 }
  );
  assert.equal(zeroActZeroCost.resultCode, JOB_STATUS_RESULT.CHECK_INPUTS);

  const blankActPrice = calculateActuals(
    { actualPrice: null, labourHours: 4, labourRate: 30 },
    { quotedPrice: 200, labourHours: 4, labourRate: 30 },
    { targetMargin: 0.4 }
  );
  assert.equal(blankActPrice.actualTotalCost, 120.0, 'Total actual cost still displays when actualPrice is blank');
  assert.equal(blankActPrice.actualProfit, null);
  assert.equal(blankActPrice.resultCode, JOB_STATUS_RESULT.CHECK_INPUTS);

  const lossAct = calculateActuals(
    { actualPrice: 0, labourHours: 2, labourRate: 30 },
    { quotedPrice: 100, labourHours: 2, labourRate: 30 },
    { targetMargin: 0.4 }
  );
  assert.equal(lossAct.resultCode, JOB_STATUS_RESULT.LOSS);
  assert.equal(lossAct.actualProfit, -60);

  assert.equal(clampMargin(1.2), 0.95);
  assert.equal(clampMargin(-0.5), 0);

  const invalidMargin = calculateEstimate({ labourHours: 2, labourRate: 30, quotedPrice: 100 }, { targetMargin: 1 });
  assert.equal(invalidMargin.recommendedPrice, null);
}

// 8. Mixed-currency Job Log summary safety
{
  const mixedJobs = [
    { status: 'completed', snapshot: { currency: 'USD', targetMargin: 0.4 }, estimate: { quotedPrice: 100, materials: 50 }, actual: { actualPrice: 100, materials: 50 } },
    { status: 'completed', snapshot: { currency: 'GBP', targetMargin: 0.4 }, estimate: { quotedPrice: 200, materials: 100 }, actual: { actualPrice: 200, materials: 100 } },
  ];
  const allSum = calculateLogSummary(mixedJobs, 'all');
  assert.equal(allSum.hasMixedCurrencies, true);
  assert.equal(allSum.revenue, null, 'Must not sum USD + GBP into one currency figure');
  assert.deepEqual(allSum.currencies, ['GBP', 'USD']);

  const gbpSum = calculateLogSummary(mixedJobs, 'GBP');
  assert.equal(gbpSum.hasMixedCurrencies, false);
  assert.equal(gbpSum.displayCurrency, 'GBP');
  assert.equal(gbpSum.revenue, 200);
  assert.equal(gbpSum.totalProfit, 100);
}

// 9. Deep JSON restore normalization on partial/missing snapshot
{
  const restored = parseBackupJSON(
    JSON.stringify({
      settings: { labourRate: 45, targetMargin: 0.5, currency: 'CAD', distanceUnit: 'mi' },
      jobs: [
        { id: 'partial1', status: 'quoted', customerName: 'Missing Snapshot', estimate: { quotedPrice: 200, materials: -10 } },
        { id: 'bad_completed', status: 'completed', customerName: 'Completed Without Actual', estimate: { quotedPrice: 100 } },
      ],
    })
  );
  assert.equal(restored.jobs.length, 2);
  assert.equal(restored.jobs[0].snapshot.currency, 'CAD');
  assert.equal(restored.jobs[0].snapshot.distanceUnit, 'mi');
  assert.equal(restored.jobs[0].estimate.materials, 0, 'Negative imported cost clamped to 0');
  assert.equal(restored.jobs[1].status, 'quoted', 'Completed job without actuals normalized back to quoted');
}

// 10. CSV export: valid structure + formula-injection neutralization without corrupting negative numbers
{
  const jobs = [
    ...createDemoJobs(),
    {
      id: 'csv_inj',
      status: 'completed',
      createdAt: '2026-10-20',
      completedDate: '2026-10-20',
      customerName: '=CMD|"/C calc"!A0',
      serviceType: '+1+1',
      notes: 'Line 1\nLine 2, "quoted"',
      snapshot: { currency: 'USD', distanceUnit: 'km', targetMargin: 0.4, taxRate: 0 },
      estimate: { quotedPrice: 100, materials: 50 },
      actual: { actualPrice: 100, materials: 70 },
    },
  ];
  const csv = exportJobsCSV(jobs, false);
  assert.ok(csv.includes("'=CMD"), 'Leading = in customerName must be neutralized');
  assert.ok(csv.includes("'+1+1"), 'Leading + in serviceType must be neutralized');
  assert.ok(csv.includes(',-42.4,'), 'Negative numeric profit variance must stay numeric');
  assert.ok(csv.includes('"Line 1\nLine 2, ""quoted"""'), 'Multiline & quoted CSV notes properly escaped');
}

console.log('All SmallBiz calculator, fuzz, normalization & CSV security tests passed!');
