/**
 * Zero-Dependency Customer Quote PDF Generator (PDF 1.4 Vector Output)
 *
 * Generates a crisp, standards-compliant .pdf binary directly in the browser
 * using built-in Helvetica / Helvetica-Bold fonts and WinAnsiEncoding so
 * $, £, €, CA$, A$, NZ$ render accurately on desktop and mobile without
 * relying on window.print() or external CDN libraries.
 */

import { calculateEstimate } from './calculator.js';
import { formatCurrency, formatTaxPercent, formatDateISO, todayISO } from './format.js';

// Map common Unicode characters outside Latin-1 to WinAnsiEncoding byte codes
const WIN_ANSI_EXTRA = {
  0x20ac: 0x80, // €
  0x201a: 0x82, // ‚
  0x201e: 0x84, // „
  0x2026: 0x85, // …
  0x2018: 0x91, // ‘
  0x2019: 0x92, // ’
  0x201c: 0x93, // “
  0x201d: 0x94, // ”
  0x2022: 0x95, // •
  0x2013: 0x96, // –
  0x2014: 0x97, // —
  0x2122: 0x99, // ™
};

function encodePdfLiteral(text) {
  const str = String(text ?? '');
  let out = '(';
  for (let i = 0; i < str.length; i += 1) {
    const cp = str.charCodeAt(i);
    let byte;
    if (cp >= 0x20 && cp <= 0x7e) {
      byte = cp;
    } else if (cp >= 0xa0 && cp <= 0xff) {
      byte = cp;
    } else if (WIN_ANSI_EXTRA[cp] !== undefined) {
      byte = WIN_ANSI_EXTRA[cp];
    } else if (cp === 0x00b7) {
      byte = 0xb7; // middle dot ·
    } else {
      byte = 0x3f; // fallback '?'
    }

    if (byte === 0x28 || byte === 0x29 || byte === 0x5c) {
      out += `\\${String.fromCharCode(byte)}`;
    } else if (byte >= 0x20 && byte <= 0x7e) {
      out += String.fromCharCode(byte);
    } else {
      out += `\\${byte.toString(8).padStart(3, '0')}`;
    }
  }
  out += ')';
  return out;
}

/**
 * Simple word wrapper calibrated for Helvetica font metrics.
 */
function wrapLines(text, maxCharsPerLine) {
  const paragraphs = String(text ?? '').replace(/\r\n/g, '\n').split('\n');
  const lines = [];
  for (const para of paragraphs) {
    const trimmed = para.trim();
    if (!trimmed) {
      lines.push('');
      continue;
    }
    const words = trimmed.split(/\s+/);
    let current = '';
    for (const word of words) {
      if (!current) {
        current = word;
      } else if (current.length + 1 + word.length <= maxCharsPerLine) {
        current += ` ${word}`;
      } else {
        lines.push(current);
        current = word;
      }
    }
    if (current) lines.push(current);
  }
  return lines;
}

/**
 * Approximate text width in points for right-alignment in Helvetica.
 */
function approxWidthPt(text, fontSize, isBold = false) {
  const avgFactor = isBold ? 0.56 : 0.52;
  let units = 0;
  for (const ch of String(text ?? '')) {
    if ('ilI.,:;!| '.includes(ch)) units += 0.28;
    else if ('mwMW@'.includes(ch)) units += 0.84;
    else if ('0123456789$£€+-'.includes(ch)) units += 0.56;
    else if (ch >= 'A' && ch <= 'Z') units += 0.66;
    else units += avgFactor;
  }
  return units * fontSize;
}

/**
 * Build a complete PDF 1.4 Uint8Array for a customer-facing quote
 * (hides all internal costs, labour rates, and profit margins).
 */
export function buildCustomerQuotePdfBytes(job, settings = {}) {
  const snap = job.snapshot || {};
  const est = calculateEstimate(job.estimate, snap);
  const curr = snap.currency || settings.currency || 'USD';

  const bizName = (settings.businessName || '').trim() || 'Service Estimate';
  const contact = [settings.businessPhone, settings.businessEmail]
    .map((x) => (x || '').trim())
    .filter(Boolean)
    .join(' · ');
  const quoteDate = formatDateISO(job.createdAt || todayISO());
  const validity = (settings.quoteValidity || '').trim();
  const footerNote = (settings.quoteFooterNote || '').trim();
  const customerName = (job.customerName || '').trim() || 'Valued Customer';
  const serviceType = (job.serviceType || '').trim() || 'Service Job';
  const notes = (job.notes || '').trim();

  const hasPrice = est.quotedPrice !== null && est.quotedPrice > 0;
  const hasTax = est.taxRate > 0 && hasPrice;

  // US Letter (612 x 792 pt)
  const PAGE_W = 612;
  const PAGE_H = 792;
  const MARGIN = 50;
  const CONTENT_W = PAGE_W - MARGIN * 2;
  const RIGHT_X = PAGE_W - MARGIN;

  const ops = [];
  const textAt = (x, y, str, font, size, rgb = [0.08, 0.16, 0.14]) => {
    ops.push(
      `BT /${font} ${size} Tf ${rgb[0]} ${rgb[1]} ${rgb[2]} rg 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(
        2
      )} Tm ${encodePdfLiteral(str)} Tj ET`
    );
  };
  const textRight = (rightX, y, str, font, size, rgb = [0.08, 0.16, 0.14]) => {
    const w = approxWidthPt(str, size, font === 'F2');
    textAt(Math.max(MARGIN, rightX - w), y, str, font, size, rgb);
  };

  // Top forest-green brand bar
  ops.push(`0.055 0.298 0.227 rg 0 ${PAGE_H - 18} ${PAGE_W} 18 re f`);

  // Header block
  let y = PAGE_H - 64;
  textAt(MARGIN, y, bizName, 'F2', 18, [0.035, 0.19, 0.14]);
  textRight(RIGHT_X, y + 4, 'CUSTOMER QUOTE', 'F2', 9, [0.11, 0.45, 0.34]);
  textRight(RIGHT_X, y - 12, `Date: ${quoteDate}`, 'F1', 10, [0.32, 0.4, 0.37]);

  if (contact) {
    textAt(MARGIN, y - 18, contact, 'F1', 10, [0.32, 0.4, 0.37]);
  }
  if (validity) {
    textRight(RIGHT_X, y - 26, validity, 'F1', 10, [0.32, 0.4, 0.37]);
  }

  // Deep green divider line
  y -= 42;
  ops.push(`0.055 0.298 0.227 RG 1.6 w ${MARGIN} ${y} m ${RIGHT_X} ${y} l S`);

  // Prepared For & Service (2 columns)
  y -= 28;
  const col2X = MARGIN + CONTENT_W * 0.52;
  textAt(MARGIN, y, 'PREPARED FOR', 'F2', 8.5, [0.45, 0.52, 0.49]);
  textAt(col2X, y, 'SERVICE', 'F2', 8.5, [0.45, 0.52, 0.49]);

  y -= 17;
  textAt(MARGIN, y, customerName, 'F2', 12, [0.08, 0.16, 0.14]);
  textAt(col2X, y, serviceType, 'F2', 12, [0.08, 0.16, 0.14]);

  // Optional Scope & Notes
  if (notes) {
    y -= 30;
    textAt(MARGIN, y, 'SCOPE & NOTES', 'F2', 8.5, [0.45, 0.52, 0.49]);
    y -= 16;
    const noteLines = wrapLines(notes, 82).slice(0, 14);
    for (const line of noteLines) {
      if (line) {
        textAt(MARGIN, y, line, 'F1', 10.5, [0.16, 0.24, 0.22]);
      }
      y -= 15;
    }
    y -= 6;
  } else {
    y -= 28;
  }

  // Totals Box (soft mint fill + crisp border)
  const boxH = hasTax ? 108 : 74;
  const boxY = y - boxH;
  ops.push(`0.945 0.976 0.960 rg 0.78 0.88 0.84 RG 1 w ${MARGIN} ${boxY} ${CONTENT_W} ${boxH} re B`);

  const innerLeft = MARGIN + 18;
  const innerRight = RIGHT_X - 18;

  if (hasTax) {
    let ty = y - 24;
    textAt(innerLeft, ty, 'Quoted service price (excl. tax)', 'F1', 10.5, [0.28, 0.36, 0.33]);
    textRight(innerRight, ty, formatCurrency(est.quotedPrice, curr), 'F1', 10.5, [0.08, 0.16, 0.14]);

    ty -= 20;
    textAt(
      innerLeft,
      ty,
      `Estimated tax (${formatTaxPercent(est.taxRate)})`,
      'F1',
      10.5,
      [0.28, 0.36, 0.33]
    );
    textRight(innerRight, ty, formatCurrency(est.taxAmount, curr), 'F1', 10.5, [0.08, 0.16, 0.14]);

    ty -= 14;
    ops.push(`0.78 0.88 0.84 RG 0.8 w ${innerLeft} ${ty} m ${innerRight} ${ty} l S`);

    ty -= 22;
    textAt(innerLeft, ty, 'Total Quote (incl. tax)', 'F2', 14, [0.035, 0.19, 0.14]);
    textRight(
      innerRight,
      ty,
      formatCurrency(est.quotedPriceInclTax, curr),
      'F2',
      14,
      [0.035, 0.19, 0.14]
    );
  } else {
    const ty = y - 32;
    textAt(innerLeft, ty, 'Quoted Price', 'F2', 14, [0.035, 0.19, 0.14]);
    textRight(
      innerRight,
      ty,
      hasPrice ? formatCurrency(est.quotedPrice, curr) : 'TBD',
      'F2',
      15,
      [0.035, 0.19, 0.14]
    );
    textAt(
      innerLeft,
      ty - 20,
      'Price excludes separately charged sales tax where applicable.',
      'F1',
      9,
      [0.42, 0.49, 0.47]
    );
  }

  // Footer note
  y = boxY - 26;
  if (footerNote) {
    const footerLines = wrapLines(footerNote, 88).slice(0, 6);
    for (const line of footerLines) {
      if (line) {
        textAt(MARGIN, y, line, 'F1', 9.5, [0.32, 0.4, 0.37]);
      }
      y -= 14;
    }
  }

  // Assemble PDF 1.4 objects with exact byte offsets
  const stream = ops.join('\n');
  const objects = [
    '1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n',
    '2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n',
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>\nendobj\n`,
    '4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n',
    '5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n',
    `6 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`,
  ];

  const enc = new TextEncoder();
  const chunks = [];
  const offsets = [0];
  let byteOffset = 0;

  const pushStr = (s) => {
    const bytes = enc.encode(s);
    chunks.push(bytes);
    byteOffset += bytes.length;
  };

  pushStr('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  for (const obj of objects) {
    offsets.push(byteOffset);
    pushStr(obj);
  }

  const xrefOffset = byteOffset;
  pushStr(`xref\n0 ${objects.length + 1}\n`);
  pushStr('0000000000 65535 f \n');
  for (let i = 1; i <= objects.length; i += 1) {
    pushStr(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
  }
  pushStr(
    `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`
  );

  const totalLen = chunks.reduce((acc, c) => acc + c.length, 0);
  const pdf = new Uint8Array(totalLen);
  let pos = 0;
  for (const c of chunks) {
    pdf.set(c, pos);
    pos += c.length;
  }
  return pdf;
}

export function buildQuotePdfFilename(job) {
  const slug = String(job.customerName || 'customer-quote')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 40);
  return `quote-${slug || 'estimate'}-${todayISO()}.pdf`;
}

export function downloadCustomerQuotePdf(job, settings) {
  const bytes = buildCustomerQuotePdfBytes(job, settings);
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = buildQuotePdfFilename(job);
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
