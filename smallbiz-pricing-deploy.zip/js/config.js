/**
 * Application Configuration
 *
 * Leave supabaseUrl and supabaseAnonKey empty to run in Local Multi-User Mode
 * (perfect for testing User A vs. User B, the 2 quotes/month paywall, and
 * simulated lifetime unlock without needing external keys).
 *
 * When ready to go live, fill in your Supabase project URL, anon key, and
 * Lemon Squeezy one-time checkout URL (see SETUP_CLOUD.md).
 */

export const APP_CONFIG = {
  // Supabase project settings (Settings -> API in Supabase dashboard)
  supabaseUrl: '',
  supabaseAnonKey: '',

  // Lemon Squeezy hosted checkout link for your one-time lifetime product
  // Example: 'https://yourstore.lemonsqueezy.com/buy/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
  lemonCheckoutUrl: '',

  // Pricing & Free Tier display
  lifetimePriceLabel: '$29',
  freeMonthlyLimit: 2,
};

export function isCloudConfigured() {
  return Boolean(
    APP_CONFIG.supabaseUrl &&
      APP_CONFIG.supabaseUrl.trim() &&
      APP_CONFIG.supabaseAnonKey &&
      APP_CONFIG.supabaseAnonKey.trim()
  );
}
