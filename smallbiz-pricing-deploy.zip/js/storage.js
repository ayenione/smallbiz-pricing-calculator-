/**
 * Local-first persistence (localStorage), deep schema normalization,
 * JSON backup/restore, and formula-safe RFC-4180 CSV export.
 */

import { DEFAULT_SETTINGS, createDemoJobs } from './demoData.js';
import { calculateActuals, calculateEstimate, clampMargin, parseNum } from './calculator.js';

const STORAGE_KEY = 'smallbiz_job_profit_pricing_v1';
const SCHEMA_VERSION = 1;

export function loadState() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createInitialState();
    }
    const parsed = JSON.parse(raw);
    return normalizeState(parsed);
  } catch {
    return createInitialState();
  }
}

export function createInitialState() {
  return {
    schemaVersion: SCHEMA_VERSION,
    settings: { ...DEFAULT_SETTINGS },
    jobs: createDemoJobs(),
    demoDismissed: false,
  };
}

export function saveState(state) {
  try {
    const payload = {
      schemaVersion: SCHEMA_VERSION,
      settings: state.settings,
      jobs: state.jobs,
      demoDismissed: Boolean(state.demoDismissed),
    };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    return true;
  } catch {
    return false;
  }
}

function nonNegOrNull(val) {
  const n = parseNum(val);
  if (n === null) return null;
  return Math.max(0, n);
}

function nonNegOrDefault(val, fallback) {
  const n = parseNum(val);
  if (n === null) return fallback;
  return Math.max(0, n);
}

/**
 * Deeply normalize a single job record so missing/partial snapshots or fields
 * from edited JSON backups never crash the UI.
 */
export function normalizeJob(raw, fallbackSettings = DEFAULT_SETTINGS) {
  if (!raw || typeof raw !== 'object' || !raw.id || !raw.estimate || typeof raw.estimate !== 'object') {
    return null;
  }

  const rawSnap = raw.snapshot && typeof raw.snapshot === 'object' ? raw.snapshot : {};
  const snapshot = {
    targetMargin: clampMargin(rawSnap.targetMargin ?? fallbackSettings.targetMargin),
    taxRate: Math.max(0, Math.min(0.5, parseNum(rawSnap.taxRate) ?? fallbackSettings.taxRate)),
    currency:
      typeof rawSnap.currency === 'string' && rawSnap.currency.length === 3
        ? rawSnap.currency.toUpperCase()
        : fallbackSettings.currency,
    distanceUnit: rawSnap.distanceUnit === 'mi' ? 'mi' : rawSnap.distanceUnit === 'km' ? 'km' : fallbackSettings.distanceUnit,
    defaultLabourRate: nonNegOrDefault(rawSnap.defaultLabourRate, fallbackSettings.labourRate),
    defaultTravelRate: nonNegOrDefault(rawSnap.defaultTravelRate, fallbackSettings.travelRate),
    defaultOverhead: nonNegOrDefault(rawSnap.defaultOverhead, fallbackSettings.overheadPerJob),
  };

  const e = raw.estimate;
  const labourRate = nonNegOrDefault(e.labourRate, snapshot.defaultLabourRate);
  const travelRate = nonNegOrDefault(e.travelRate, snapshot.defaultTravelRate);
  const overhead = nonNegOrDefault(e.overhead, snapshot.defaultOverhead);

  const estimate = {
    quotedPrice: nonNegOrNull(e.quotedPrice),
    labourHours: nonNegOrNull(e.labourHours),
    labourRate,
    labourRateOverridden: Math.abs(labourRate - snapshot.defaultLabourRate) > 0.001,
    materials: nonNegOrDefault(e.materials, 0),
    travelDistance: nonNegOrDefault(e.travelDistance, 0),
    travelRate,
    travelRateOverridden: Math.abs(travelRate - snapshot.defaultTravelRate) > 0.001,
    equipment: nonNegOrDefault(e.equipment, 0),
    subcontractor: nonNegOrDefault(e.subcontractor, 0),
    otherDirect: nonNegOrDefault(e.otherDirect, 0),
    overhead,
    overheadOverridden: Math.abs(overhead - snapshot.defaultOverhead) > 0.001,
  };

  let actual = null;
  if (raw.actual && typeof raw.actual === 'object') {
    const a = raw.actual;
    actual = {
      actualPrice: nonNegOrNull(a.actualPrice),
      labourHours: nonNegOrDefault(a.labourHours, 0),
      labourRate: nonNegOrDefault(a.labourRate, snapshot.defaultLabourRate),
      materials: nonNegOrDefault(a.materials, 0),
      travelDistance: nonNegOrDefault(a.travelDistance, 0),
      travelRate: nonNegOrDefault(a.travelRate, snapshot.defaultTravelRate),
      equipment: nonNegOrDefault(a.equipment, 0),
      subcontractor: nonNegOrDefault(a.subcontractor, 0),
      otherDirect: nonNegOrDefault(a.otherDirect, 0),
      overhead: nonNegOrDefault(a.overhead, snapshot.defaultOverhead),
    };
  }

  const status = raw.status === 'completed' && actual ? 'completed' : 'quoted';

  return {
    id: String(raw.id),
    isDemo: Boolean(raw.isDemo),
    createdAt: typeof raw.createdAt === 'string' && raw.createdAt ? raw.createdAt : '',
    completedDate: status === 'completed' && typeof raw.completedDate === 'string' ? raw.completedDate : null,
    status,
    customerName: typeof raw.customerName === 'string' ? raw.customerName : '',
    serviceType: typeof raw.serviceType === 'string' ? raw.serviceType : '',
    notes: typeof raw.notes === 'string' ? raw.notes : '',
    snapshot,
    estimate,
    actual,
  };
}

export function normalizeState(raw) {
  if (!raw || typeof raw !== 'object') return createInitialState();
  const s = raw.settings && typeof raw.settings === 'object' ? raw.settings : {};
  const settings = {
    ...DEFAULT_SETTINGS,
    ...s,
    labourRate: nonNegOrDefault(s.labourRate, DEFAULT_SETTINGS.labourRate),
    targetMargin: clampMargin(s.targetMargin ?? DEFAULT_SETTINGS.targetMargin),
    overheadPerJob: nonNegOrDefault(s.overheadPerJob, DEFAULT_SETTINGS.overheadPerJob),
    travelRate: nonNegOrDefault(s.travelRate, DEFAULT_SETTINGS.travelRate),
    taxRate: Math.max(0, Math.min(0.5, parseNum(s.taxRate) ?? DEFAULT_SETTINGS.taxRate)),
    currency:
      typeof s.currency === 'string' && s.currency.length === 3
        ? s.currency.toUpperCase()
        : 'USD',
    distanceUnit: s.distanceUnit === 'mi' ? 'mi' : 'km',
    businessName: typeof s.businessName === 'string' ? s.businessName : '',
    businessPhone: typeof s.businessPhone === 'string' ? s.businessPhone : '',
    businessEmail: typeof s.businessEmail === 'string' ? s.businessEmail : '',
    quoteValidity: typeof s.quoteValidity === 'string' ? s.quoteValidity : DEFAULT_SETTINGS.quoteValidity,
    quoteFooterNote: typeof s.quoteFooterNote === 'string' ? s.quoteFooterNote : DEFAULT_SETTINGS.quoteFooterNote,
  };

  const jobs = Array.isArray(raw.jobs)
    ? raw.jobs.map((j) => normalizeJob(j, settings)).filter(Boolean)
    : [];

  return {
    schemaVersion: SCHEMA_VERSION,
    settings,
    jobs,
    demoDismissed: Boolean(raw.demoDismissed),
  };
}

export function exportBackupJSON(state) {
  const payload = {
    app: 'SmallBiz Job Profit & Pricing Calculator',
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    settings: state.settings,
    jobs: state.jobs,
  };
  return JSON.stringify(payload, null, 2);
}

export function parseBackupJSON(jsonText) {
  const parsed = JSON.parse(jsonText);
  if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.jobs)) {
    throw new Error('Invalid backup file: expected a JSON export containing settings and jobs.');
  }
  return normalizeState(parsed);
}

/**
 * RFC-4180 CSV export of all jobs with formula-injection protection on text fields.
 */
export function exportJobsCSV(jobs = [], includeQuoted = false) {
  const rows = includeQuoted ? jobs : jobs.filter((j) => j.status === 'completed' && j.actual);
  const headers = [
    'Date',
    'Status',
    'Job / Customer',
    'Service Type',
    'Currency',
    'Quoted Price (excl. tax)',
    'Estimated Cost',
    'Estimated Profit',
    'Actual Revenue (excl. tax)',
    'Labour Hours',
    'Labour Rate',
    'Materials',
    'Travel Distance',
    'Distance Unit',
    'Travel Rate',
    'Equipment / Rental',
    'Subcontractor',
    'Other Direct',
    'Allocated Overhead',
    'Actual Total Cost',
    'Actual Profit',
    'Actual Margin %',
    'Profit Variance (Actual - Est)',
    'Result',
    'Notes',
  ];

  const lines = [headers.map((h) => csvCell(h, false)).join(',')];

  for (const job of rows) {
    const est = calculateEstimate(job.estimate, job.snapshot);
    const act = calculateActuals(job.actual, job.estimate, job.snapshot);
    const dateVal = job.completedDate || job.createdAt || '';
    const unit = job.snapshot?.distanceUnit || 'km';
    const curr = job.snapshot?.currency || 'USD';

    const row = [
      csvCell(dateVal, false),
      csvCell(job.status === 'completed' ? 'Completed' : 'Quoted', false),
      csvCell(job.customerName || '', false),
      csvCell(job.serviceType || '', false),
      csvCell(curr, false),
      csvCell(numOrEmpty(est.quotedPrice), true),
      csvCell(numOrEmpty(est.totalCost), true),
      csvCell(numOrEmpty(est.expectedProfit), true),
      csvCell(numOrEmpty(act.actualPrice), true),
      csvCell(job.actual ? numOrEmpty(job.actual.labourHours) : numOrEmpty(job.estimate.labourHours), true),
      csvCell(job.actual ? numOrEmpty(job.actual.labourRate) : numOrEmpty(job.estimate.labourRate), true),
      csvCell(job.actual ? numOrEmpty(job.actual.materials) : numOrEmpty(job.estimate.materials), true),
      csvCell(job.actual ? numOrEmpty(job.actual.travelDistance) : numOrEmpty(job.estimate.travelDistance), true),
      csvCell(unit, false),
      csvCell(job.actual ? numOrEmpty(job.actual.travelRate) : numOrEmpty(job.estimate.travelRate), true),
      csvCell(job.actual ? numOrEmpty(job.actual.equipment) : numOrEmpty(job.estimate.equipment), true),
      csvCell(job.actual ? numOrEmpty(job.actual.subcontractor) : numOrEmpty(job.estimate.subcontractor), true),
      csvCell(job.actual ? numOrEmpty(job.actual.otherDirect) : numOrEmpty(job.estimate.otherDirect), true),
      csvCell(job.actual ? numOrEmpty(job.actual.overhead) : numOrEmpty(job.estimate.overhead), true),
      csvCell(numOrEmpty(act.actualTotalCost), true),
      csvCell(numOrEmpty(act.actualProfit), true),
      csvCell(act.actualMargin !== null ? `${(act.actualMargin * 100).toFixed(1)}%` : '', true),
      csvCell(numOrEmpty(act.profitVariance), true),
      csvCell(job.status === 'completed' ? act.resultLabel : est.resultLabel, false),
      csvCell(job.notes || '', false),
    ];
    lines.push(row.join(','));
  }

  return lines.join('\r\n');
}

function numOrEmpty(v) {
  return v === null || v === undefined || !Number.isFinite(v) ? '' : String(v);
}

/**
 * Neutralize spreadsheet formula injection on text cells (leading =, +, -, @, tab, CR)
 * while leaving numeric cells (including negative numbers like -42.4) untouched.
 */
function csvCell(val, isNumeric = false) {
  let s = String(val ?? '');
  if (!isNumeric && /^[=+\-@\t\r]/.test(s)) {
    s = `'${s}`;
  }
  if (/[",\r\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function triggerDownload(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
