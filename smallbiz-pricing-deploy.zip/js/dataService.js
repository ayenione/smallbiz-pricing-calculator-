/**
 * Unified Data Service Facade
 * Automatically uses Supabase when APP_CONFIG keys are provided, or falls back
 * cleanly to Local Multi-User Mode for offline/demo testing.
 */

import { isCloudConfigured } from './config.js';
import { createLocalMultiUserProvider } from './providers/localMultiUserProvider.js';
import { createSupabaseProvider } from './providers/supabaseProvider.js';

let activeProvider = null;

export function getDataService() {
  if (!activeProvider) {
    activeProvider = isCloudConfigured()
      ? createSupabaseProvider()
      : createLocalMultiUserProvider();
  }
  return activeProvider;
}
