/**
 * Formatting helpers for currency, percentages, signed deltas, and dates.
 */

export const SUPPORTED_CURRENCIES = [
  { code: 'USD', label: 'USD ($)', symbol: '$' },
  { code: 'CAD', label: 'CAD ($)', symbol: 'CA$' },
  { code: 'GBP', label: 'GBP (£)', symbol: '£' },
  { code: 'EUR', label: 'EUR (€)', symbol: '€' },
  { code: 'AUD', label: 'AUD ($)', symbol: 'A$' },
  { code: 'NZD', label: 'NZD ($)', symbol: 'NZ$' },
];

const formatterCache = new Map();

function getCurrencyFormatter(currency = 'USD') {
  const key = currency || 'USD';
  if (!formatterCache.has(key)) {
    try {
      formatterCache.set(
        key,
        new Intl.NumberFormat(undefined, {
          style: 'currency',
          currency: key,
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })
      );
    } catch {
      formatterCache.set(
        key,
        new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })
      );
    }
  }
  return formatterCache.get(key);
}

export function getCurrencySymbol(currency = 'USD') {
  const found = SUPPORTED_CURRENCIES.find((c) => c.code === currency);
  return found ? found.symbol : '$';
}

export function formatCurrency(value, currency = 'USD', fallback = '—') {
  if (value === null || value === undefined || !Number.isFinite(value)) return fallback;
  const normalized = Math.abs(value) < 0.005 ? 0 : value;
  return getCurrencyFormatter(currency).format(normalized);
}

export function formatSignedCurrency(value, currency = 'USD', fallback = '—') {
  if (value === null || value === undefined || !Number.isFinite(value)) return fallback;
  if (Math.abs(value) < 0.005) return formatCurrency(0, currency);
  const abs = formatCurrency(Math.abs(value), currency);
  return value > 0 ? `+${abs}` : `-${abs}`;
}

export function formatPercent(ratio, decimals = 1, fallback = '—') {
  if (ratio === null || ratio === undefined || !Number.isFinite(ratio)) return fallback;
  return `${(ratio * 100).toFixed(decimals)}%`;
}

export function formatTaxPercent(ratio, fallback = '0%') {
  if (ratio === null || ratio === undefined || !Number.isFinite(ratio)) return fallback;
  return `${Number((ratio * 100).toFixed(3))}%`;
}

export function formatSignedPercentPoints(ratioDiff, decimals = 1, fallback = '—') {
  if (ratioDiff === null || ratioDiff === undefined || !Number.isFinite(ratioDiff)) return fallback;
  const pts = ratioDiff * 100;
  if (Math.abs(pts) < 0.05) return '0.0 pts';
  return `${pts > 0 ? '+' : ''}${pts.toFixed(decimals)} pts`;
}

export function formatNumber(value, maxDecimals = 2, fallback = '—') {
  if (value === null || value === undefined || !Number.isFinite(value)) return fallback;
  return new Intl.NumberFormat(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: maxDecimals,
  }).format(value);
}

export function formatDateISO(dateStr) {
  if (!dateStr) return '—';
  // Expect YYYY-MM-DD
  const parts = String(dateStr).split('-');
  if (parts.length !== 3) return dateStr;
  const dt = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  if (Number.isNaN(dt.getTime())) return dateStr;
  return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

export function todayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
