/**
 * Production Supabase Cloud Provider
 *
 * Connects to Supabase Auth + Postgres (Row-Level Security) + create_job_with_quota RPC
 * and builds signed Lemon Squeezy checkout URLs passing custom_data.user_id.
 */

import { APP_CONFIG } from '../config.js';
import { DEFAULT_SETTINGS } from '../demoData.js';
import { normalizeJob, normalizeState } from '../storage.js';
import { getUtcYearMonth } from './localMultiUserProvider.js';

let clientPromise = null;

async function getSupabaseClient() {
  if (!clientPromise) {
    clientPromise = import('https://esm.sh/@supabase/supabase-js@2').then(({ createClient }) =>
      createClient(APP_CONFIG.supabaseUrl, APP_CONFIG.supabaseAnonKey)
    );
  }
  return clientPromise;
}

function mapDbRowToJob(row, fallbackSettings) {
  return normalizeJob(
    {
      id: row.id,
      isDemo: false,
      createdAt: row.created_at,
      completedDate: row.completed_date,
      status: row.status,
      customerName: row.customer_name,
      serviceType: row.service_type,
      notes: row.notes,
      snapshot: row.snapshot,
      estimate: row.estimate,
      actual: row.actual,
    },
    fallbackSettings
  );
}

export function createSupabaseProvider() {
  return {
    mode: 'cloud',

    async getSession() {
      const sb = await getSupabaseClient();
      const { data, error } = await sb.auth.getSession();
      if (error) throw new Error(error.message);
      const u = data?.session?.user || null;
      return { user: u ? { id: u.id, email: u.email } : null };
    },

    async signUp({ email, password }) {
      const sb = await getSupabaseClient();
      const { data, error } = await sb.auth.signUp({
        email: String(email || '').trim().toLowerCase(),
        password: String(password || ''),
      });
      if (error) throw new Error(error.message);
      const u = data?.user;
      return {
        user: u ? { id: u.id, email: u.email } : null,
        requiresEmailConfirmation: !data?.session,
      };
    },

    async signIn({ email, password }) {
      const sb = await getSupabaseClient();
      const { data, error } = await sb.auth.signInWithPassword({
        email: String(email || '').trim().toLowerCase(),
        password: String(password || ''),
      });
      if (error) throw new Error(error.message);
      return { user: { id: data.user.id, email: data.user.email } };
    },

    async signOut() {
      const sb = await getSupabaseClient();
      const { error } = await sb.auth.signOut();
      if (error) throw new Error(error.message);
    },

    async requestPasswordReset(email) {
      const sb = await getSupabaseClient();
      const cleanEmail = String(email || '').trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        throw new Error('Enter your account email address first.');
      }
      const { error } = await sb.auth.resetPasswordForEmail(cleanEmail, {
        redirectTo: window.location.origin + window.location.pathname,
      });
      if (error) throw new Error(error.message);
      return { message: `Password reset email sent to ${cleanEmail}.` };
    },

    async loadAccountData() {
      const sb = await getSupabaseClient();
      const { data: sessionData } = await sb.auth.getSession();
      const user = sessionData?.session?.user;
      if (!user) {
        const err = new Error('Please sign in first.');
        err.code = 'AUTH_REQUIRED';
        throw err;
      }

      const ym = getUtcYearMonth();
      const [profRes, usageRes, jobsRes] = await Promise.all([
        sb.from('profiles').select('id, email, plan, unlocked_at, settings').eq('id', user.id).single(),
        sb
          .from('monthly_quote_usage')
          .select('year_month, quotes_created')
          .eq('user_id', user.id)
          .eq('year_month', ym)
          .maybeSingle(),
        sb.from('jobs').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      ]);

      if (profRes.error) throw new Error(profRes.error.message);
      if (usageRes.error) throw new Error(usageRes.error.message);
      if (jobsRes.error) throw new Error(jobsRes.error.message);

      const normalizedSettings = normalizeState({
        settings: profRes.data?.settings || DEFAULT_SETTINGS,
        jobs: [],
      }).settings;

      const jobs = (jobsRes.data || [])
        .map((row) => mapDbRowToJob(row, normalizedSettings))
        .filter(Boolean);

      return {
        profile: {
          id: profRes.data.id,
          email: profRes.data.email || user.email,
          plan: profRes.data.plan === 'lifetime' ? 'lifetime' : 'free',
          unlockedAt: profRes.data.unlocked_at || null,
          settings: normalizedSettings,
        },
        usage: {
          yearMonth: ym,
          quotesCreated: Number(usageRes.data?.quotes_created || 0),
          limit: APP_CONFIG.freeMonthlyLimit,
        },
        jobs,
      };
    },

    async saveSettings(settings) {
      const sb = await getSupabaseClient();
      const { data: sessionData } = await sb.auth.getSession();
      const user = sessionData?.session?.user;
      if (!user) throw new Error('Not signed in');

      const normalized = normalizeState({ settings, jobs: [] }).settings;
      const { error } = await sb
        .from('profiles')
        .update({ settings: normalized })
        .eq('id', user.id);
      if (error) throw new Error(error.message);
      return normalized;
    },

    async createJobWithQuota(jobDraft) {
      const sb = await getSupabaseClient();
      const { data, error } = await sb.rpc('create_job_with_quota', {
        p_customer_name: jobDraft.customerName || 'Untitled job',
        p_service_type: jobDraft.serviceType || '',
        p_notes: jobDraft.notes || '',
        p_status: jobDraft.status || 'quoted',
        p_created_at: jobDraft.createdAt || null,
        p_completed_date: jobDraft.completedDate || null,
        p_snapshot: jobDraft.snapshot,
        p_estimate: jobDraft.estimate,
        p_actual: jobDraft.actual || null,
      });

      if (error) {
        if (String(error.message || '').includes('QUOTA_EXCEEDED')) {
          const err = new Error('Free monthly quote limit reached.');
          err.code = 'QUOTA_EXCEEDED';
          throw err;
        }
        throw new Error(error.message);
      }

      return {
        job: mapDbRowToJob(data.job, DEFAULT_SETTINGS),
        usage: {
          yearMonth: data.usage.year_month,
          quotesCreated: Number(data.usage.quotes_created),
          limit: Number(data.usage.limit),
        },
      };
    },

    async updateJob(job) {
      const sb = await getSupabaseClient();
      const { data, error } = await sb
        .from('jobs')
        .update({
          status: job.status,
          customer_name: job.customerName || 'Untitled job',
          service_type: job.serviceType || '',
          notes: job.notes || '',
          completed_date: job.completedDate || null,
          snapshot: job.snapshot,
          estimate: job.estimate,
          actual: job.actual || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', job.id)
        .select('*')
        .single();

      if (error) throw new Error(error.message);
      return mapDbRowToJob(data, DEFAULT_SETTINGS);
    },

    async deleteJob(jobId) {
      const sb = await getSupabaseClient();
      const { error } = await sb.from('jobs').delete().eq('id', jobId);
      if (error) throw new Error(error.message);
    },

    getCheckoutUrl({ user, returnUrl }) {
      const base = (APP_CONFIG.lemonCheckoutUrl || '').trim();
      if (!base || !user) return null;
      const url = new URL(base);
      url.searchParams.set('checkout[custom][user_id]', user.id);
      if (user.email) url.searchParams.set('checkout[email]', user.email);
      if (returnUrl) url.searchParams.set('checkout[success_url]', returnUrl);
      return url.toString();
    },

    async unlockLifetimeTest() {
      throw new Error('Test unlock is disabled in live cloud mode. Complete checkout via Lemon Squeezy.');
    },
  };
}
