/**
 * Local Multi-User Storage Provider
 *
 * Implements the exact same async Auth + Multi-Tenant DB + Atomic Monthly Quota
 * contract as supabaseProvider.js, stored per-browser in localStorage (with
 * automatic in-memory fallback in Node tests or sandboxed iframes).
 *
 * Lets you test User A (landscaper) vs. User B (cleaner) data isolation,
 * the immutable 2-quotes/month limit, and one-time lifetime unlock right away.
 */

import { APP_CONFIG } from '../config.js';
import { DEFAULT_SETTINGS } from '../demoData.js';
import { normalizeJob, normalizeState } from '../storage.js';

const DB_KEY = 'smallbiz_local_cloud_db_v1';

export function getUtcYearMonth(date = new Date()) {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

async function hashPassword(password, salt) {
  const input = `${salt}:${password}`;
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // Fallback deterministic hash (only if Web Crypto unavailable)
  let h = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

function makeMemoryStorage() {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k),
  };
}

function resolveStorage(customStorage) {
  if (customStorage) return customStorage;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const probe = '__sb_probe__';
      window.localStorage.setItem(probe, '1');
      window.localStorage.removeItem(probe);
      return window.localStorage;
    }
  } catch {
    // Sandboxed iframe or private mode
  }
  return makeMemoryStorage();
}

export function createLocalMultiUserProvider({
  storage = null,
  nowFn = () => new Date(),
  freeMonthlyLimit = APP_CONFIG.freeMonthlyLimit,
} = {}) {
  const store = resolveStorage(storage);

  function readDb() {
    try {
      const raw = store.getItem(DB_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object' && parsed.users) {
          return parsed;
        }
      }
    } catch {
      // ignore corrupted storage
    }
    return {
      currentUserId: null,
      users: {}, // userId -> { id, email, salt, passwordHash, plan, unlockedAt, settings }
      jobsByUser: {}, // userId -> Job[]
      usageByUser: {}, // userId -> { [YYYY-MM]: number }
    };
  }

  function writeDb(db) {
    try {
      store.setItem(DB_KEY, JSON.stringify(db));
      return true;
    } catch {
      return false;
    }
  }

  function requireUser(db) {
    if (!db.currentUserId || !db.users[db.currentUserId]) {
      const err = new Error('Please sign in to save your work.');
      err.code = 'AUTH_REQUIRED';
      throw err;
    }
    return db.users[db.currentUserId];
  }

  function formatUsage(db, userId) {
    const ym = getUtcYearMonth(nowFn());
    const userUsage = db.usageByUser[userId] || {};
    return {
      yearMonth: ym,
      quotesCreated: Number(userUsage[ym] || 0),
      limit: freeMonthlyLimit,
    };
  }

  return {
    mode: 'local',

    async getSession() {
      const db = readDb();
      const u = db.currentUserId ? db.users[db.currentUserId] : null;
      return { user: u ? { id: u.id, email: u.email } : null };
    },

    async signUp({ email, password }) {
      const cleanEmail = String(email || '').trim().toLowerCase();
      if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        throw new Error('Please enter a valid email address.');
      }
      if (!password || String(password).length < 6) {
        throw new Error('Password must be at least 6 characters.');
      }

      const db = readDb();
      const exists = Object.values(db.users).some((u) => u.email === cleanEmail);
      if (exists) {
        throw new Error('An account with this email already exists. Try logging in instead.');
      }

      const id = `usr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
      const salt = Math.random().toString(36).slice(2, 12);
      const passwordHash = await hashPassword(String(password), salt);

      db.users[id] = {
        id,
        email: cleanEmail,
        salt,
        passwordHash,
        plan: 'free',
        unlockedAt: null,
        settings: { ...DEFAULT_SETTINGS },
      };
      db.jobsByUser[id] = [];
      db.usageByUser[id] = {};
      db.currentUserId = id;
      writeDb(db);

      return { user: { id, email: cleanEmail }, requiresEmailConfirmation: false };
    },

    async signIn({ email, password }) {
      const cleanEmail = String(email || '').trim().toLowerCase();
      const db = readDb();
      const user = Object.values(db.users).find((u) => u.email === cleanEmail);
      if (!user) {
        throw new Error('Invalid email or password.');
      }
      const attempt = await hashPassword(String(password || ''), user.salt);
      if (attempt !== user.passwordHash) {
        throw new Error('Invalid email or password.');
      }
      db.currentUserId = user.id;
      writeDb(db);
      return { user: { id: user.id, email: user.email } };
    },

    async signOut() {
      const db = readDb();
      db.currentUserId = null;
      writeDb(db);
    },

    async requestPasswordReset(email) {
      const cleanEmail = String(email || '').trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        throw new Error('Enter your account email address first.');
      }
      return {
        message: `Local demo mode: in production, Supabase sends a password reset link to ${cleanEmail}.`,
      };
    },

    async loadAccountData() {
      const db = readDb();
      const u = requireUser(db);
      const normalized = normalizeState({ settings: u.settings, jobs: db.jobsByUser[u.id] || [] });
      return {
        profile: {
          id: u.id,
          email: u.email,
          plan: u.plan === 'lifetime' ? 'lifetime' : 'free',
          unlockedAt: u.unlockedAt || null,
          settings: normalized.settings,
        },
        usage: formatUsage(db, u.id),
        jobs: normalized.jobs,
      };
    },

    async saveSettings(settings) {
      const db = readDb();
      const u = requireUser(db);
      const normalized = normalizeState({ settings, jobs: [] });
      u.settings = normalized.settings;
      writeDb(db);
      return u.settings;
    },

    async createJobWithQuota(jobDraft) {
      const db = readDb();
      const u = requireUser(db);
      const ym = getUtcYearMonth(nowFn());
      if (!db.usageByUser[u.id]) db.usageByUser[u.id] = {};
      const used = Number(db.usageByUser[u.id][ym] || 0);

      if (u.plan !== 'lifetime' && used >= freeMonthlyLimit) {
        const err = new Error(
          `You have reached your free limit of ${freeMonthlyLimit} saved quotes for ${ym}.`
        );
        err.code = 'QUOTA_EXCEEDED';
        err.usage = { yearMonth: ym, quotesCreated: used, limit: freeMonthlyLimit };
        throw err;
      }

      const newId = `job_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
      const normalized = normalizeJob(
        {
          ...jobDraft,
          id: newId,
          isDemo: false,
        },
        u.settings
      );

      if (!db.jobsByUser[u.id]) db.jobsByUser[u.id] = [];
      db.jobsByUser[u.id].unshift(normalized);
      db.usageByUser[u.id][ym] = used + 1;
      writeDb(db);

      return {
        job: normalized,
        usage: { yearMonth: ym, quotesCreated: used + 1, limit: freeMonthlyLimit },
      };
    },

    async updateJob(job) {
      const db = readDb();
      const u = requireUser(db);
      const list = db.jobsByUser[u.id] || [];
      const idx = list.findIndex((j) => j.id === job.id);
      if (idx === -1) {
        throw new Error('Job not found in your account.');
      }
      const normalized = normalizeJob({ ...job, isDemo: false }, u.settings);
      list[idx] = normalized;
      db.jobsByUser[u.id] = list;
      writeDb(db);
      return normalized;
    },

    async deleteJob(jobId) {
      const db = readDb();
      const u = requireUser(db);
      const list = db.jobsByUser[u.id] || [];
      db.jobsByUser[u.id] = list.filter((j) => j.id !== jobId);
      // Intentionally does NOT decrement db.usageByUser[u.id][ym]
      writeDb(db);
    },

    getCheckoutUrl() {
      return null; // Local mode uses simulated one-time unlock
    },

    async unlockLifetimeTest() {
      const db = readDb();
      const u = requireUser(db);
      u.plan = 'lifetime';
      u.unlockedAt = new Date().toISOString();
      writeDb(db);
      return {
        plan: u.plan,
        unlockedAt: u.unlockedAt,
      };
    },
  };
}
