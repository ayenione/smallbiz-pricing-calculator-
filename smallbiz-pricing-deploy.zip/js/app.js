/**
 * SmallBiz Job Profit & Pricing Calculator — Multi-User Freemium UI Controller
 *
 * Supports Guest Mode (interactive demo preview) + Authenticated Multi-Tenant
 * Workspaces via dataService (Supabase Cloud or Local Multi-User Mode),
 * atomic 2-quotes/month free limit, and one-time Lifetime Pro unlock.
 */

import {
  calculateEstimate,
  calculateActuals,
  calculateLogSummary,
  clampMargin,
  parseNum,
  JOB_STATUS_RESULT,
} from './calculator.js';
import {
  SUPPORTED_CURRENCIES,
  getCurrencySymbol,
  formatCurrency,
  formatSignedCurrency,
  formatPercent,
  formatTaxPercent,
  formatSignedPercentPoints,
  formatNumber,
  formatDateISO,
  todayISO,
  escapeHtml,
} from './format.js';
import { DEFAULT_SETTINGS, createDemoJobs } from './demoData.js';
import { exportBackupJSON, parseBackupJSON, exportJobsCSV, triggerDownload } from './storage.js';
import { downloadCustomerQuotePdf } from './pdfQuote.js';
import { APP_CONFIG } from './config.js';
import { getDataService } from './dataService.js';

const dataService = getDataService();

// ---------- Application State ----------

let currentUser = null; // null (guest) | { id, email }
let accountPlan = 'free'; // 'free' | 'lifetime'
let accountUsage = { yearMonth: '', quotesCreated: 0, limit: APP_CONFIG.freeMonthlyLimit };

let state = createGuestState();
let activeView = 'quote'; // 'quote' | 'actuals' | 'log'
let quoteDraft = createBlankDraft(state.settings);
let editingQuoteId = null; // null => creating new quote, otherwise job.id
let selectedActualJobId = null;
let actualDraft = null;
let modalQuoteJob = null;

// Auth modal & guest-to-account draft persistence
let authMode = 'signup'; // 'signup' | 'signin' | 'reset'
let pendingPostAuthAction = null; // { type: 'save_quote', draft, goToActuals } | null

// ---------- Helpers ----------

const $ = (id) => document.getElementById(id);

function createGuestState() {
  return {
    settings: { ...DEFAULT_SETTINGS },
    jobs: createDemoJobs(),
    demoDismissed: false,
  };
}

function createBlankDraft(settings) {
  return {
    id: null,
    isDemo: false,
    createdAt: todayISO(),
    completedDate: null,
    status: 'quoted',
    customerName: '',
    serviceType: '',
    notes: '',
    snapshot: {
      targetMargin: settings.targetMargin,
      taxRate: settings.taxRate,
      currency: settings.currency,
      distanceUnit: settings.distanceUnit,
      defaultLabourRate: settings.labourRate,
      defaultTravelRate: settings.travelRate,
      defaultOverhead: settings.overheadPerJob,
    },
    estimate: {
      quotedPrice: null,
      labourHours: null,
      labourRate: settings.labourRate,
      labourRateOverridden: false,
      materials: 0,
      travelDistance: 0,
      travelRate: settings.travelRate,
      travelRateOverridden: false,
      equipment: 0,
      subcontractor: 0,
      otherDirect: 0,
      overhead: settings.overheadPerJob,
      overheadOverridden: false,
    },
    actual: null,
  };
}

function cloneJob(job) {
  return JSON.parse(JSON.stringify(job));
}

function prefillActualFromEstimate(job) {
  const e = job.estimate;
  return {
    actualPrice: e.quotedPrice ?? null,
    labourHours: e.labourHours ?? 0,
    labourRate: e.labourRate ?? job.snapshot.defaultLabourRate,
    materials: e.materials ?? 0,
    travelDistance: e.travelDistance ?? 0,
    travelRate: e.travelRate ?? job.snapshot.defaultTravelRate,
    equipment: e.equipment ?? 0,
    subcontractor: e.subcontractor ?? 0,
    otherDirect: e.otherDirect ?? 0,
    overhead: e.overhead ?? job.snapshot.defaultOverhead,
  };
}

function showToast(message) {
  const region = $('toast-region');
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = message;
  region.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 180ms ease';
    setTimeout(() => el.remove(), 200);
  }, 3000);
}

function setInputValue(id, val) {
  const el = $(id);
  if (!el) return;
  el.value = val === null || val === undefined ? '' : String(val);
}

function validateNonNegativeForm(formId, alertId) {
  const form = $(formId);
  const alertEl = $(alertId);
  if (!form) return true;

  let hasNegative = false;
  form.querySelectorAll('input[type="number"]').forEach((input) => {
    const val = parseNum(input.value);
    const bad = val !== null && val < 0;
    input.classList.toggle('is-invalid', bad);
    input.setAttribute('aria-invalid', String(bad));
    if (bad) hasNegative = true;
  });

  if (alertEl) alertEl.hidden = !hasNegative;
  return !hasNegative;
}

// ---------- Account / Plan / Chrome ----------

function applyConfigLabels() {
  document.querySelectorAll('.js-free-limit').forEach((el) => {
    el.textContent = String(APP_CONFIG.freeMonthlyLimit);
  });
  document.querySelectorAll('.js-lifetime-price').forEach((el) => {
    el.textContent = APP_CONFIG.lifetimePriceLabel;
  });
}

function renderGlobalChrome() {
  $('nav-log-count').textContent = String(state.jobs.length);

  const isSignedIn = Boolean(currentUser);
  $('auth-guest-controls').hidden = isSignedIn;
  $('auth-user-controls').hidden = !isSignedIn;

  if (isSignedIn) {
    const emailEl = $('header-user-email');
    emailEl.textContent = currentUser.email;
    emailEl.title = currentUser.email;

    const pill = $('btn-header-plan');
    if (accountPlan === 'lifetime') {
      pill.className = 'plan-pill is-pro tabular';
      pill.textContent = 'Lifetime Pro';
      pill.title = 'Unlimited saved quotes unlocked forever';
    } else {
      const limit = accountUsage.limit || APP_CONFIG.freeMonthlyLimit;
      const used = accountUsage.quotesCreated || 0;
      const remaining = Math.max(0, limit - used);
      pill.className = `plan-pill tabular${remaining === 0 ? ' is-limit' : ''}`;
      pill.textContent = `Free · ${remaining}/${limit} left`;
      pill.title = `${used} of ${limit} free quotes used this month — click to unlock unlimited`;
    }
  }

  // Show guest demo banner only when browsing as a guest with demo jobs present
  const hasDemo = state.jobs.some((j) => j.isDemo);
  $('demo-banner').hidden = isSignedIn || !hasDemo || state.demoDismissed;
}

async function loadAuthenticatedWorkspace({ preservePendingDraft = false } = {}) {
  const data = await dataService.loadAccountData();
  currentUser = { id: data.profile.id, email: data.profile.email };
  accountPlan = data.profile.plan;
  accountUsage = data.usage;
  state = {
    settings: data.profile.settings,
    jobs: data.jobs,
    demoDismissed: true,
  };

  if (!preservePendingDraft) {
    const firstOpen = state.jobs.find((j) => j.status === 'quoted');
    loadJobIntoQuoteEditor(firstOpen ? firstOpen.id : null);
    selectedActualJobId = null;
    actualDraft = null;
  }

  renderGlobalChrome();
  switchView(activeView);
}

function enterGuestWorkspace() {
  currentUser = null;
  accountPlan = 'free';
  accountUsage = { yearMonth: '', quotesCreated: 0, limit: APP_CONFIG.freeMonthlyLimit };
  state = createGuestState();
  selectedActualJobId = null;
  actualDraft = null;
  const firstOpen = state.jobs.find((j) => j.status === 'quoted');
  loadJobIntoQuoteEditor(firstOpen ? firstOpen.id : null);
  renderGlobalChrome();
  switchView('quote');
}

// ---------- Navigation ----------

function switchView(view) {
  activeView = view;
  document.querySelectorAll('.nav-tab').forEach((btn) => {
    btn.setAttribute('aria-selected', String(btn.dataset.view === view));
  });
  document.querySelectorAll('.view-panel').forEach((panel) => {
    panel.hidden = panel.id !== `view-${view}`;
  });

  if (view === 'quote') {
    if (editingQuoteId) {
      const latest = state.jobs.find((j) => j.id === editingQuoteId);
      if (latest) {
        quoteDraft.status = latest.status;
        quoteDraft.completedDate = latest.completedDate;
        quoteDraft.actual = latest.actual ? cloneJob(latest.actual) : null;
      }
    }
    renderQuoteSelector();
    renderQuoteForm();
    renderQuoteSummary();
  } else if (view === 'actuals') {
    ensureActualSelection();
    renderActualsView();
  } else if (view === 'log') {
    renderJobLog();
  }
  window.scrollTo(0, 0);
}

// ---------- VIEW 1: PRICE A JOB ----------

function loadJobIntoQuoteEditor(jobId) {
  if (!jobId) {
    editingQuoteId = null;
    quoteDraft = createBlankDraft(state.settings);
  } else {
    const found = state.jobs.find((j) => j.id === jobId);
    if (found) {
      editingQuoteId = found.id;
      quoteDraft = cloneJob(found);
    } else {
      editingQuoteId = null;
      quoteDraft = createBlankDraft(state.settings);
    }
  }
  renderQuoteSelector();
  renderQuoteForm();
  renderQuoteSummary();
}

function renderQuoteSelector() {
  const sel = $('quote-job-select');
  const openQuotes = state.jobs.filter((j) => j.status === 'quoted');
  const completedJobs = state.jobs.filter((j) => j.status === 'completed');

  const options = ['<option value="">+ New quote draft</option>'];
  if (openQuotes.length > 0) {
    options.push('<optgroup label="Open Quotes">');
    for (const j of openQuotes) {
      const label = `${j.customerName || 'Untitled job'}${j.serviceType ? ` — ${j.serviceType}` : ''}`;
      options.push(`<option value="${escapeHtml(j.id)}">${escapeHtml(label)}</option>`);
    }
    options.push('</optgroup>');
  }
  if (completedJobs.length > 0) {
    options.push('<optgroup label="Completed Jobs">');
    for (const j of completedJobs) {
      const label = `${j.customerName || 'Untitled job'} (Completed ${j.completedDate || ''})`;
      options.push(`<option value="${escapeHtml(j.id)}">${escapeHtml(label)}</option>`);
    }
    options.push('</optgroup>');
  }

  sel.innerHTML = options.join('');
  sel.value = editingQuoteId || '';

  const badge = $('quote-lifecycle-badge');
  $('btn-duplicate-quote').hidden = !editingQuoteId;
  if (!editingQuoteId) {
    badge.className = 'status-badge quoted';
    badge.textContent = 'New draft';
  } else if (quoteDraft.status === 'completed') {
    badge.className = 'status-badge on_target';
    badge.textContent = 'Completed job';
  } else {
    badge.className = 'status-badge quoted';
    badge.textContent = 'Saved quote';
  }
}

function renderQuoteForm() {
  const snap = quoteDraft.snapshot;
  const est = quoteDraft.estimate;
  const sym = getCurrencySymbol(snap.currency);
  const unit = snap.distanceUnit || 'km';

  document.querySelectorAll('.js-currency-symbol').forEach((el) => {
    el.textContent = sym;
  });
  document.querySelectorAll('.js-distance-unit').forEach((el) => {
    el.textContent = unit;
  });

  $('quote-assumptions-summary').textContent = `Target ${formatPercent(snap.targetMargin)} · ${snap.currency} · ${unit}`;

  setInputValue('q-customer', quoteDraft.customerName);
  setInputValue('q-service', quoteDraft.serviceType);
  setInputValue('q-notes', quoteDraft.notes);
  setInputValue('q-price', est.quotedPrice);
  setInputValue('q-labour-hours', est.labourHours);
  setInputValue('q-labour-rate', est.labourRate);
  setInputValue('q-travel-dist', est.travelDistance);
  setInputValue('q-travel-rate', est.travelRate);
  setInputValue('q-materials', est.materials);
  setInputValue('q-equipment', est.equipment);
  setInputValue('q-subcontractor', est.subcontractor);
  setInputValue('q-other', est.otherDirect);
  setInputValue('q-overhead', est.overhead);

  updateOverridePill('pill-q-labour-rate', est.labourRateOverridden);
  updateOverridePill('pill-q-travel-rate', est.travelRateOverridden);
  updateOverridePill('pill-q-overhead', est.overheadOverridden);
  validateNonNegativeForm('quote-form', 'quote-validation-alert');
}

function updateOverridePill(id, isCustom) {
  const pill = $(id);
  if (!pill) return;
  pill.classList.toggle('is-custom', Boolean(isCustom));
  pill.textContent = isCustom ? 'Custom · Reset' : 'Default';
}

function readQuoteFormIntoDraft() {
  const snap = quoteDraft.snapshot;
  const est = quoteDraft.estimate;

  quoteDraft.customerName = $('q-customer').value.trim();
  quoteDraft.serviceType = $('q-service').value.trim();
  quoteDraft.notes = $('q-notes').value;

  est.quotedPrice = parseNum($('q-price').value);
  est.labourHours = parseNum($('q-labour-hours').value);
  est.labourRate = parseNum($('q-labour-rate').value);
  est.labourRateOverridden =
    est.labourRate !== null && Math.abs(est.labourRate - snap.defaultLabourRate) > 0.001;

  est.travelDistance = parseNum($('q-travel-dist').value);
  est.travelRate = parseNum($('q-travel-rate').value);
  est.travelRateOverridden =
    est.travelRate !== null && Math.abs(est.travelRate - snap.defaultTravelRate) > 0.001;

  est.materials = parseNum($('q-materials').value);
  est.equipment = parseNum($('q-equipment').value);
  est.subcontractor = parseNum($('q-subcontractor').value);
  est.otherDirect = parseNum($('q-other').value);
  est.overhead = parseNum($('q-overhead').value);
  est.overheadOverridden =
    est.overhead !== null && Math.abs(est.overhead - snap.defaultOverhead) > 0.001;

  updateOverridePill('pill-q-labour-rate', est.labourRateOverridden);
  updateOverridePill('pill-q-travel-rate', est.travelRateOverridden);
  updateOverridePill('pill-q-overhead', est.overheadOverridden);
  validateNonNegativeForm('quote-form', 'quote-validation-alert');
}

function renderQuoteSummary() {
  const snap = quoteDraft.snapshot;
  const currency = snap.currency;
  const res = calculateEstimate(quoteDraft.estimate, snap);

  const badge = $('q-status-badge');
  badge.className = `status-badge ${res.resultCode}`;
  badge.textContent = res.resultLabel;

  $('q-recommended-price').textContent = formatCurrency(res.recommendedPrice, currency);
  $('q-target-margin-label').textContent = `at ${formatPercent(res.targetMargin)} target margin`;
  $('btn-apply-recommended').disabled = res.recommendedPrice === null || res.hasNegativeInput;

  const diffCallout = $('q-diff-callout');
  if (res.hasNegativeInput) {
    diffCallout.innerHTML =
      '<strong class="val-negative">Check inputs:</strong> Remove negative numbers to calculate accurate pricing.';
  } else if (res.resultCode === JOB_STATUS_RESULT.CHECK_INPUTS) {
    diffCallout.textContent = 'Enter your job costs and a quoted price to check profitability.';
  } else if (res.resultCode === JOB_STATUS_RESULT.LOSS) {
    diffCallout.innerHTML = `<strong class="val-negative">Warning:</strong> Quoted price is ${formatCurrency(
      Math.abs(res.expectedProfit),
      currency
    )} below break-even cost.`;
  } else if (res.resultCode === JOB_STATUS_RESULT.BELOW_TARGET) {
    diffCallout.innerHTML = `<strong class="val-warn">${formatCurrency(
      Math.abs(res.diffFromRecommended),
      currency
    )} below</strong> your recommended price for ${formatPercent(res.targetMargin)} margin.`;
  } else {
    const cushion =
      res.diffFromRecommended > 0.005
        ? `${formatCurrency(res.diffFromRecommended, currency)} above recommended price.`
        : 'Right on your target margin.';
    diffCallout.innerHTML = `<strong class="val-positive">Meets target:</strong> ${cushion}`;
  }

  $('q-expected-margin-top').textContent = formatPercent(res.expectedMargin);
  const vsGoalEl = $('q-margin-vs-goal');
  vsGoalEl.textContent =
    res.marginVsGoal !== null
      ? `${formatSignedPercentPoints(res.marginVsGoal)} vs goal`
      : `Goal: ${formatPercent(res.targetMargin)}`;
  vsGoalEl.className =
    'tabular ' +
    (res.marginVsGoal === null
      ? ''
      : res.marginVsGoal >= -0.0005
      ? 'val-positive'
      : res.expectedProfit !== null && res.expectedProfit < 0
      ? 'val-negative'
      : 'val-warn');

  const fill = $('q-margin-fill');
  const clampedFill =
    res.expectedMargin !== null ? Math.max(0, Math.min(100, res.expectedMargin * 100)) : 0;
  fill.style.width = `${clampedFill}%`;
  fill.classList.toggle('is-loss', res.resultCode === JOB_STATUS_RESULT.LOSS);
  fill.classList.toggle('is-warn', res.resultCode === JOB_STATUS_RESULT.BELOW_TARGET);

  const markerPos = res.targetMargin !== null ? Math.max(0, Math.min(100, res.targetMargin * 100)) : 40;
  $('q-margin-target-marker').style.left = `${markerPos}%`;

  $('q-total-cost-top').textContent = formatCurrency(res.totalCost, currency);
  const total = res.totalCost || 0;
  const bd = res.breakdown;
  const pct = (v) => (total > 0 ? `${((v / total) * 100).toFixed(2)}%` : '0%');
  $('seg-q-labour').style.width = pct(bd.labourCost);
  $('seg-q-materials').style.width = pct(bd.materials);
  $('seg-q-travel').style.width = pct(bd.travelCost);
  $('seg-q-direct').style.width = pct(bd.directOtherCost);
  $('seg-q-overhead').style.width = pct(bd.overhead);

  const legendItems = [
    { label: 'Labour', val: bd.labourCost, color: 'var(--seg-labour)' },
    { label: 'Materials', val: bd.materials, color: 'var(--seg-materials)' },
    { label: 'Travel', val: bd.travelCost, color: 'var(--seg-travel)' },
    { label: 'Equip/Other', val: bd.directOtherCost, color: 'var(--seg-direct)' },
    { label: 'Overhead', val: bd.overhead, color: 'var(--seg-overhead)' },
  ].filter((x) => x.val > 0);

  $('q-cost-legend').innerHTML = legendItems.length
    ? legendItems
        .map(
          (item) =>
            `<span class="legend-item"><span class="legend-dot" style="background:${item.color}"></span>${
              item.label
            } ${formatCurrency(item.val, currency)}</span>`
        )
        .join('')
    : '<span>No costs entered yet</span>';

  const profitEl = $('q-expected-profit');
  profitEl.textContent = formatCurrency(res.expectedProfit, currency);
  profitEl.className =
    'metric-value tabular ' +
    (res.expectedProfit === null ? '' : res.expectedProfit < 0 ? 'val-negative' : 'val-positive');

  $('q-break-even').textContent = formatCurrency(res.breakEvenPrice, currency);

  const diffEl = $('q-diff-recommended');
  diffEl.textContent = formatSignedCurrency(res.diffFromRecommended, currency);
  diffEl.className =
    'metric-value tabular ' +
    (res.diffFromRecommended === null
      ? ''
      : res.diffFromRecommended < -0.005
      ? 'val-warn'
      : 'val-positive');

  $('q-tax-row-label').textContent =
    res.taxRate > 0
      ? `Quoted price incl. ${formatTaxPercent(res.taxRate)} tax`
      : 'Quoted price incl. tax (0%)';
  $('q-price-incl-tax').textContent = formatCurrency(res.quotedPriceInclTax, currency);
}

async function saveCurrentQuote({ silent = false, goToActualsAfter = false } = {}) {
  readQuoteFormIntoDraft();
  if (!validateNonNegativeForm('quote-form', 'quote-validation-alert')) {
    showToast('Please fix negative values before saving');
    return null;
  }

  if (!quoteDraft.customerName) {
    quoteDraft.customerName = quoteDraft.serviceType
      ? `${quoteDraft.serviceType} quote`
      : `Job ${todayISO()}`;
    setInputValue('q-customer', quoteDraft.customerName);
  }

  // Guest user -> prompt free signup/login and automatically save this draft afterward!
  if (!currentUser) {
    pendingPostAuthAction = {
      type: 'save_quote',
      draft: cloneJob(quoteDraft),
      goToActualsAfter,
    };
    openAuthModal('signup', { fromSave: true });
    return null;
  }

  quoteDraft.isDemo = false;

  try {
    if (editingQuoteId) {
      const idx = state.jobs.findIndex((j) => j.id === editingQuoteId);
      if (idx !== -1) {
        // Updating an existing saved quote is ALWAYS free & preserves actuals
        const existing = state.jobs[idx];
        const merged = {
          ...cloneJob(quoteDraft),
          id: existing.id,
          status: existing.status,
          completedDate: existing.completedDate,
          actual: existing.actual ? cloneJob(existing.actual) : null,
        };
        const updated = await dataService.updateJob(merged);
        state.jobs[idx] = updated;
        quoteDraft = cloneJob(updated);
        if (selectedActualJobId === existing.id && existing.status === 'quoted') {
          actualDraft = null;
        }
        renderGlobalChrome();
        renderQuoteSelector();
        if (!silent) showToast(`Updated quote for "${updated.customerName}"`);
        return updated.id;
      }
    }

    // Creating a NEW quote -> enforce monthly quota atomically on server/provider
    const res = await dataService.createJobWithQuota({
      ...cloneJob(quoteDraft),
      createdAt: todayISO(),
      status: 'quoted',
      completedDate: null,
      actual: null,
    });

    state.jobs.unshift(res.job);
    accountUsage = res.usage;
    editingQuoteId = res.job.id;
    quoteDraft = cloneJob(res.job);

    renderGlobalChrome();
    renderQuoteSelector();
    if (!silent) {
      const suffix =
        accountPlan === 'free'
          ? ` (${res.usage.quotesCreated}/${res.usage.limit} free quotes used this month)`
          : '';
      showToast(`Saved quote for "${res.job.customerName}"${suffix}`);
    }
    return res.job.id;
  } catch (err) {
    if (err.code === 'QUOTA_EXCEEDED') {
      if (err.usage) accountUsage = err.usage;
      renderGlobalChrome();
      openUpgradeModal({ triggeredByLimit: true });
      return null;
    }
    showToast(err.message || 'Could not save quote');
    return null;
  }
}

// ---------- VIEW 2: RECORD ACTUALS ----------

function ensureActualSelection() {
  if (selectedActualJobId && state.jobs.some((j) => j.id === selectedActualJobId)) {
    return;
  }
  const openQuote = state.jobs.find((j) => j.status === 'quoted');
  selectedActualJobId = openQuote ? openQuote.id : state.jobs[0]?.id || null;
}

function loadJobForActuals(jobId) {
  selectedActualJobId = jobId;
  const job = state.jobs.find((j) => j.id === jobId);
  if (!job) {
    actualDraft = null;
    return;
  }
  actualDraft = {
    jobId: job.id,
    completedDate: job.completedDate || todayISO(),
    values: job.actual ? { ...job.actual } : prefillActualFromEstimate(job),
    wasPrefilled: !job.actual,
  };
}

function renderActualsView() {
  const hasJobs = state.jobs.length > 0;
  $('actuals-empty').hidden = hasJobs;
  $('actuals-workspace').hidden = !hasJobs;

  const sel = $('actual-job-select');
  if (!hasJobs) {
    sel.innerHTML = '<option value="">No jobs available</option>';
    return;
  }

  const openQuotes = state.jobs.filter((j) => j.status === 'quoted');
  const completed = state.jobs.filter((j) => j.status === 'completed');
  const opts = [];
  if (openQuotes.length) {
    opts.push('<optgroup label="Open Quotes (Ready to Complete)">');
    for (const j of openQuotes) {
      opts.push(
        `<option value="${escapeHtml(j.id)}">${escapeHtml(j.customerName || 'Untitled')} — ${escapeHtml(
          j.serviceType || 'Service'
        )}</option>`
      );
    }
    opts.push('</optgroup>');
  }
  if (completed.length) {
    opts.push('<optgroup label="Completed Jobs">');
    for (const j of completed) {
      opts.push(
        `<option value="${escapeHtml(j.id)}">${escapeHtml(j.customerName || 'Untitled')} (${
          j.completedDate || 'Completed'
        })</option>`
      );
    }
    opts.push('</optgroup>');
  }
  sel.innerHTML = opts.join('');
  sel.value = selectedActualJobId || '';

  const job = state.jobs.find((j) => j.id === selectedActualJobId);
  if (!job) return;

  if (!actualDraft || actualDraft.jobId !== job.id) {
    loadJobForActuals(job.id);
  }

  const stateBadge = $('actual-job-state-badge');
  if (job.status === 'completed') {
    stateBadge.className = 'status-badge on_target';
    stateBadge.textContent = 'Completed';
  } else {
    stateBadge.className = 'status-badge quoted';
    stateBadge.textContent = 'Open quote';
  }

  $('actuals-prefill-notice').hidden = !actualDraft.wasPrefilled;

  const snap = job.snapshot;
  const est = job.estimate;
  const act = actualDraft.values;
  const curr = snap.currency;
  const sym = getCurrencySymbol(curr);
  const unit = snap.distanceUnit || 'km';

  document.querySelectorAll('.js-actual-currency').forEach((el) => {
    el.textContent = sym;
  });
  document.querySelectorAll('.js-actual-unit').forEach((el) => {
    el.textContent = unit;
  });

  setInputValue('a-date', actualDraft.completedDate);
  setInputValue('a-price', act.actualPrice);
  setInputValue('a-labour-hours', act.labourHours);
  setInputValue('a-labour-rate', act.labourRate);
  setInputValue('a-travel-dist', act.travelDistance);
  setInputValue('a-travel-rate', act.travelRate);
  setInputValue('a-materials', act.materials);
  setInputValue('a-equipment', act.equipment);
  setInputValue('a-subcontractor', act.subcontractor);
  setInputValue('a-other', act.otherDirect);
  setInputValue('a-overhead', act.overhead);

  $('ref-a-price').textContent = `Est: ${formatCurrency(est.quotedPrice, curr)}`;
  $('ref-a-labour-hours').textContent = `Est: ${formatNumber(est.labourHours ?? 0)} hrs`;
  $('ref-a-labour-rate').textContent = `Est: ${formatCurrency(est.labourRate, curr)}`;
  $('ref-a-travel-dist').textContent = `Est: ${formatNumber(est.travelDistance ?? 0)} ${unit}`;
  $('ref-a-travel-rate').textContent = `Est: ${formatCurrency(est.travelRate, curr)}`;
  $('ref-a-materials').textContent = `Est: ${formatCurrency(est.materials ?? 0, curr)}`;
  $('ref-a-equipment').textContent = `Est: ${formatCurrency(est.equipment ?? 0, curr)}`;
  $('ref-a-subcontractor').textContent = `Est: ${formatCurrency(est.subcontractor ?? 0, curr)}`;
  $('ref-a-other').textContent = `Est: ${formatCurrency(est.otherDirect ?? 0, curr)}`;
  $('ref-a-overhead').textContent = `Est: ${formatCurrency(est.overhead ?? 0, curr)}`;

  validateNonNegativeForm('actuals-form', 'actuals-validation-alert');
  renderActualsSummary(job);
}

function readActualsFormIntoDraft() {
  if (!actualDraft) return;
  actualDraft.completedDate = $('a-date').value || todayISO();
  const v = actualDraft.values;
  v.actualPrice = parseNum($('a-price').value);
  v.labourHours = parseNum($('a-labour-hours').value);
  v.labourRate = parseNum($('a-labour-rate').value);
  v.travelDistance = parseNum($('a-travel-dist').value);
  v.travelRate = parseNum($('a-travel-rate').value);
  v.materials = parseNum($('a-materials').value);
  v.equipment = parseNum($('a-equipment').value);
  v.subcontractor = parseNum($('a-subcontractor').value);
  v.otherDirect = parseNum($('a-other').value);
  v.overhead = parseNum($('a-overhead').value);
  validateNonNegativeForm('actuals-form', 'actuals-validation-alert');
}

function renderActualsSummary(job) {
  if (!job || !actualDraft) return;
  const curr = job.snapshot.currency;
  const res = calculateActuals(actualDraft.values, job.estimate, job.snapshot);

  const badge = $('a-status-badge');
  badge.className = `status-badge ${res.resultCode}`;
  badge.textContent = res.resultLabel;

  const profitBig = $('a-actual-profit');
  profitBig.textContent = formatCurrency(res.actualProfit, curr);
  profitBig.className =
    'summary-big-value tabular ' +
    (res.actualProfit !== null && res.actualProfit < 0 ? 'val-negative' : '');

  $('a-actual-margin').textContent =
    res.actualMargin !== null
      ? `${formatPercent(res.actualMargin)} margin (goal ${formatPercent(job.snapshot.targetMargin)})`
      : '—';

  const callout = $('a-variance-callout');
  if (res.hasNegativeInput) {
    callout.innerHTML =
      '<strong class="val-negative">Check inputs:</strong> Remove negative numbers to calculate actual profit.';
  } else if (res.profitVariance === null) {
    callout.textContent = 'Enter actual selling price and costs to calculate variance.';
  } else if (res.profitVariance > 0.005) {
    callout.innerHTML = `<strong class="val-positive">${formatSignedCurrency(
      res.profitVariance,
      curr
    )}</strong> ahead of estimated profit.`;
  } else if (res.profitVariance < -0.005) {
    callout.innerHTML = `<strong class="val-negative">${formatSignedCurrency(
      res.profitVariance,
      curr
    )}</strong> below estimated profit.`;
  } else {
    callout.textContent = 'Actual profit matched your estimate exactly.';
  }

  const pvEl = $('a-profit-variance');
  pvEl.textContent = formatSignedCurrency(res.profitVariance, curr);
  pvEl.className =
    'metric-value tabular ' +
    (res.profitVariance === null
      ? ''
      : res.profitVariance < -0.005
      ? 'val-negative'
      : 'val-positive');

  $('a-total-cost').textContent = formatCurrency(res.actualTotalCost, curr);
  $('a-est-profit').textContent = formatCurrency(res.estimateMetrics.expectedProfit, curr);

  const pvrEl = $('a-price-vs-rec');
  pvrEl.textContent = formatSignedCurrency(res.priceVsRecommended, curr);
  pvrEl.className =
    'metric-value tabular ' +
    (res.priceVsRecommended === null
      ? ''
      : res.priceVsRecommended < -0.005
      ? 'val-warn'
      : 'val-positive');

  const tbody = $('a-variance-tbody');
  const rows = (res.lineVariances || [])
    .filter((item) => item.estimated > 0 || item.actual > 0)
    .map((item) => {
      const diffClass =
        item.variance > 0.005 ? 'val-negative' : item.variance < -0.005 ? 'val-positive' : '';
      return `
        <tr>
          <td>${escapeHtml(item.label)}</td>
          <td class="num">${formatCurrency(item.estimated, curr)}</td>
          <td class="num">${formatCurrency(item.actual, curr)}</td>
          <td class="num ${diffClass}">${formatSignedCurrency(item.variance, curr)}</td>
        </tr>
      `;
    });

  const totalCostDiffClass =
    res.costVariance !== null && res.costVariance > 0.005
      ? 'val-negative'
      : res.costVariance !== null && res.costVariance < -0.005
      ? 'val-positive'
      : '';

  rows.push(`
    <tr class="total-row">
      <td>Total cost</td>
      <td class="num">${formatCurrency(res.estimateMetrics.totalCost, curr)}</td>
      <td class="num">${formatCurrency(res.actualTotalCost, curr)}</td>
      <td class="num ${totalCostDiffClass}">${formatSignedCurrency(res.costVariance, curr)}</td>
    </tr>
  `);

  tbody.innerHTML = rows.join('');
}

async function saveActualsForSelectedJob() {
  const idx = state.jobs.findIndex((j) => j.id === selectedActualJobId);
  if (idx === -1 || !actualDraft) return;
  readActualsFormIntoDraft();

  if (!validateNonNegativeForm('actuals-form', 'actuals-validation-alert')) {
    showToast('Please fix negative values before saving');
    return;
  }

  const nextJob = {
    ...state.jobs[idx],
    isDemo: false,
    status: 'completed',
    completedDate: actualDraft.completedDate || todayISO(),
    actual: { ...actualDraft.values },
  };

  if (!currentUser) {
    // Guest preview: update in-memory and prompt account creation to persist
    state.jobs[idx] = nextJob;
    actualDraft.wasPrefilled = false;
    if (editingQuoteId === nextJob.id) quoteDraft = cloneJob(nextJob);
    renderGlobalChrome();
    renderActualsView();
    showToast('Updated in guest preview — create a free account to save permanently');
    return;
  }

  try {
    const saved = await dataService.updateJob(nextJob);
    state.jobs[idx] = saved;
    actualDraft.wasPrefilled = false;
    if (editingQuoteId === saved.id) quoteDraft = cloneJob(saved);
    renderGlobalChrome();
    renderActualsView();
    showToast(`Recorded actuals for "${saved.customerName}"`);
  } catch (err) {
    showToast(err.message || 'Could not save actuals');
  }
}

// ---------- VIEW 3: JOB LOG ----------

function renderJobLog() {
  const currSel = $('log-currency-filter');
  const allCurrencies = Array.from(
    new Set(state.jobs.map((j) => j.snapshot?.currency || state.settings.currency))
  ).sort();

  const prevCurr = currSel.value || 'all';
  if (allCurrencies.length > 1) {
    currSel.hidden = false;
    currSel.innerHTML =
      '<option value="all">All currencies</option>' +
      allCurrencies.map((c) => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    currSel.value = allCurrencies.includes(prevCurr) ? prevCurr : 'all';
  } else {
    currSel.hidden = true;
    currSel.innerHTML = '<option value="all">All currencies</option>';
    currSel.value = 'all';
  }

  const currencyFilter = currSel.value;
  const summary = calculateLogSummary(state.jobs, currencyFilter);
  const kpiCurr = summary.displayCurrency || state.settings.currency;

  $('log-mixed-currency-note').hidden = !summary.hasMixedCurrencies;

  $('kpi-completed').textContent = String(summary.completedCount);
  if (summary.hasMixedCurrencies) {
    $('kpi-revenue').textContent = 'Mixed';
    $('kpi-cost').textContent = 'Mixed';
    const kpiProfit = $('kpi-profit');
    kpiProfit.textContent = 'Mixed';
    kpiProfit.className = 'kpi-value';
    $('kpi-margin').textContent = '—';
  } else {
    $('kpi-revenue').textContent = formatCurrency(summary.revenue, kpiCurr);
    $('kpi-cost').textContent = formatCurrency(summary.totalCost, kpiCurr);
    const kpiProfit = $('kpi-profit');
    kpiProfit.textContent = formatCurrency(summary.totalProfit, kpiCurr);
    kpiProfit.className = 'kpi-value' + (summary.totalProfit < 0 ? ' val-negative' : '');
    $('kpi-margin').textContent = formatPercent(summary.overallMargin);
  }

  const kpiLosses = $('kpi-losses');
  kpiLosses.textContent = String(summary.lossMakingCount);
  kpiLosses.className = 'kpi-value' + (summary.lossMakingCount > 0 ? ' val-negative' : '');

  const serviceSel = $('log-service-filter');
  const prevService = serviceSel.value || 'all';
  const services = Array.from(
    new Set(state.jobs.map((j) => (j.serviceType || '').trim()).filter(Boolean))
  ).sort((a, b) => a.localeCompare(b));
  serviceSel.innerHTML =
    '<option value="all">All services</option>' +
    services.map((s) => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
  serviceSel.value = services.includes(prevService) ? prevService : 'all';

  const q = ($('log-search').value || '').trim().toLowerCase();
  const statusFilter = $('log-status-filter').value;
  const serviceFilter = serviceSel.value;

  const filtered = state.jobs.filter((job) => {
    if (q) {
      const hay = `${job.customerName || ''} ${job.serviceType || ''} ${job.notes || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (serviceFilter !== 'all' && (job.serviceType || '').trim() !== serviceFilter) {
      return false;
    }
    if (currencyFilter !== 'all' && (job.snapshot?.currency || 'USD') !== currencyFilter) {
      return false;
    }
    if (statusFilter !== 'all') {
      if (statusFilter === 'quoted') {
        if (job.status !== 'quoted') return false;
      } else {
        if (job.status !== 'completed') return false;
        const act = calculateActuals(job.actual, job.estimate, job.snapshot);
        if (act.resultCode !== statusFilter) return false;
      }
    }
    return true;
  });

  filtered.sort((a, b) => {
    const da = a.completedDate || a.createdAt || '';
    const db = b.completedDate || b.createdAt || '';
    return db.localeCompare(da);
  });

  $('log-count-label').textContent = `${filtered.length} of ${state.jobs.length} jobs`;

  const tbody = $('log-tbody');
  const empty = $('log-empty');
  if (filtered.length === 0) {
    tbody.innerHTML = '';
    empty.hidden = false;
    return;
  }
  empty.hidden = true;

  tbody.innerHTML = filtered
    .map((job) => {
      const jobCurr = job.snapshot?.currency || state.settings.currency;
      const isCompleted = job.status === 'completed' && job.actual;
      const est = calculateEstimate(job.estimate, job.snapshot);
      const act = isCompleted ? calculateActuals(job.actual, job.estimate, job.snapshot) : null;

      const dateText = formatDateISO(job.completedDate || job.createdAt);
      const badgeClass = isCompleted ? act.resultCode : 'quoted';
      const badgeText = isCompleted ? act.resultLabel : 'Open quote';

      const revenue = isCompleted ? act.actualPrice : est.quotedPrice;
      const cost = isCompleted ? act.actualTotalCost : est.totalCost;
      const profit = isCompleted ? act.actualProfit : est.expectedProfit;
      const margin = isCompleted ? act.actualMargin : est.expectedMargin;
      const variance = isCompleted ? act.profitVariance : null;

      const profitClass =
        profit === null ? '' : profit < 0 ? 'val-negative' : 'val-positive';
      const varClass =
        variance === null
          ? ''
          : variance < -0.005
          ? 'val-negative'
          : variance > 0.005
          ? 'val-positive'
          : '';

      return `
        <tr>
          <td class="tabular" style="white-space:nowrap">${escapeHtml(dateText)}</td>
          <td>
            <div class="log-job-name">
              <span>${escapeHtml(job.customerName || 'Untitled job')}</span>
              ${job.isDemo ? '<span class="demo-chip">Demo</span>' : ''}
            </div>
            <div class="log-job-service">${escapeHtml(job.serviceType || 'General service')}</div>
          </td>
          <td><span class="status-badge ${badgeClass}">${escapeHtml(badgeText)}</span></td>
          <td class="num tabular">${formatCurrency(revenue, jobCurr)}</td>
          <td class="num tabular">${formatCurrency(cost, jobCurr)}</td>
          <td class="num tabular ${profitClass}"><strong>${formatCurrency(profit, jobCurr)}</strong></td>
          <td class="num tabular">${formatPercent(margin)}</td>
          <td class="num tabular ${varClass}">${
            isCompleted ? formatSignedCurrency(variance, jobCurr) : '<span class="field-hint">Est.</span>'
          }</td>
          <td class="num">
            <div class="row-actions">
              <button class="btn btn-ghost btn-sm" type="button" data-action="edit-quote" data-id="${escapeHtml(
                job.id
              )}">Quote</button>
              <button class="btn btn-mint btn-sm" type="button" data-action="record-actuals" data-id="${escapeHtml(
                job.id
              )}">${isCompleted ? 'Actuals' : 'Complete'}</button>
              <button class="btn btn-ghost btn-sm" type="button" data-action="customer-quote" data-id="${escapeHtml(
                job.id
              )}">Print</button>
              <button class="btn btn-danger-ghost btn-sm" type="button" data-action="delete-job" data-id="${escapeHtml(
                job.id
              )}" aria-label="Delete job">✕</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join('');
}

// ---------- AUTH MODAL ----------

function setAuthMode(mode) {
  authMode = mode;
  $('auth-error-alert').hidden = true;
  $('auth-info-alert').hidden = true;

  const isSignup = mode === 'signup';
  const isReset = mode === 'reset';

  $('auth-tab-signup').setAttribute('aria-selected', String(isSignup));
  $('auth-tab-signin').setAttribute('aria-selected', String(mode === 'signin'));
  $('auth-password-field').hidden = isReset;
  $('btn-auth-forgot').hidden = isReset;
  $('btn-auth-back-signin').hidden = !isReset;

  if (isSignup) {
    $('auth-modal-title').textContent = 'Create Free Account';
    $('btn-auth-submit').textContent = 'Create Free Account';
    $('auth-password').setAttribute('autocomplete', 'new-password');
  } else if (isReset) {
    $('auth-modal-title').textContent = 'Reset Password';
    $('btn-auth-submit').textContent = 'Send Reset Link';
  } else {
    $('auth-modal-title').textContent = 'Log In to Your Account';
    $('btn-auth-submit').textContent = 'Log In';
    $('auth-password').setAttribute('autocomplete', 'current-password');
  }
}

function openAuthModal(mode = 'signup', { fromSave = false } = {}) {
  setAuthMode(mode);
  $('auth-context-banner').hidden = !fromSave;
  $('auth-mode-note').hidden = dataService.mode !== 'local';
  $('auth-password').value = '';
  openOverlay('auth-modal-overlay');
  setTimeout(() => $('auth-email').focus(), 40);
}

async function handleAuthSubmit(e) {
  e.preventDefault();
  const email = $('auth-email').value.trim();
  const password = $('auth-password').value;
  const errEl = $('auth-error-alert');
  const infoEl = $('auth-info-alert');
  errEl.hidden = true;
  infoEl.hidden = true;

  const submitBtn = $('btn-auth-submit');
  submitBtn.disabled = true;

  try {
    if (authMode === 'reset') {
      const res = await dataService.requestPasswordReset(email);
      infoEl.textContent = res.message;
      infoEl.hidden = false;
      return;
    }

    if (authMode === 'signup') {
      const res = await dataService.signUp({ email, password });
      if (res.requiresEmailConfirmation) {
        infoEl.textContent = `Check ${email} to confirm your account, then log in.`;
        infoEl.hidden = false;
        return;
      }
      showToast(`Welcome! Signed in as ${res.user.email}`);
    } else {
      const res = await dataService.signIn({ email, password });
      showToast(`Signed in as ${res.user.email}`);
    }

    closeOverlay('auth-modal-overlay');

    const pending = pendingPostAuthAction;
    pendingPostAuthAction = null;

    if (pending && pending.type === 'save_quote') {
      await loadAuthenticatedWorkspace({ preservePendingDraft: true });
      editingQuoteId = null;
      quoteDraft = cloneJob(pending.draft);
      quoteDraft.id = null;
      quoteDraft.isDemo = false;
      renderQuoteSelector();
      renderQuoteForm();
      renderQuoteSummary();
      const savedId = await saveCurrentQuote({ silent: false });
      if (savedId && pending.goToActualsAfter) {
        selectedActualJobId = savedId;
        actualDraft = null;
        switchView('actuals');
      }
    } else {
      await loadAuthenticatedWorkspace();
    }
  } catch (err) {
    errEl.textContent = err.message || 'Authentication failed. Please check your details.';
    errEl.hidden = false;
  } finally {
    submitBtn.disabled = false;
  }
}

// ---------- UPGRADE TO LIFETIME MODAL ----------

function openUpgradeModal({ triggeredByLimit = false } = {}) {
  const limit = accountUsage.limit || APP_CONFIG.freeMonthlyLimit;
  const used = accountUsage.quotesCreated || 0;
  const banner = $('upgrade-usage-banner');

  if (accountPlan === 'lifetime') {
    showToast('Your account already has Lifetime Pro — unlimited quotes unlocked!');
    return;
  }

  if (triggeredByLimit || used >= limit) {
    banner.className = 'warning-callout tabular';
    banner.innerHTML = `You have used <strong>${used} of ${limit}</strong> free saved quotes for ${escapeHtml(
      accountUsage.yearMonth || 'this month'
    )}. Unlock Lifetime Pro to save unlimited quotes forever.`;
  } else {
    banner.className = 'info-callout tabular';
    banner.innerHTML = `Free plan: <strong>${used} of ${limit}</strong> saved quotes used this month. Upgrade anytime for a one-time fee.`;
  }

  const isLocal = dataService.mode === 'local';
  $('upgrade-local-note').hidden = !isLocal;
  $('btn-upgrade-refresh').hidden = isLocal;
  $('btn-upgrade-checkout').textContent = isLocal
    ? `Simulate ${APP_CONFIG.lifetimePriceLabel} Lifetime Unlock (Local Test)`
    : `Unlock Unlimited Forever (${APP_CONFIG.lifetimePriceLabel} one-time)`;

  openOverlay('upgrade-modal-overlay');
}

async function handleUpgradeCheckout() {
  if (!currentUser) {
    closeOverlay('upgrade-modal-overlay');
    openAuthModal('signup');
    return;
  }

  if (dataService.mode === 'local') {
    try {
      await dataService.unlockLifetimeTest();
      accountPlan = 'lifetime';
      renderGlobalChrome();
      closeOverlay('upgrade-modal-overlay');
      showToast('Lifetime Pro unlocked! You can now save unlimited quotes forever.');
    } catch (err) {
      showToast(err.message || 'Could not unlock plan');
    }
    return;
  }

  const returnUrl = `${window.location.origin}${window.location.pathname}?upgraded=1`;
  const checkoutUrl = dataService.getCheckoutUrl({ user: currentUser, returnUrl });
  if (!checkoutUrl) {
    showToast('Configure APP_CONFIG.lemonCheckoutUrl in js/config.js to launch live checkout.');
    return;
  }
  window.open(checkoutUrl, '_blank', 'noopener,noreferrer');
  showToast('Checkout opened in a new tab — click Refresh Plan Status once complete.');
}

async function refreshPlanStatus() {
  if (!currentUser) return;
  try {
    const data = await dataService.loadAccountData();
    accountPlan = data.profile.plan;
    accountUsage = data.usage;
    renderGlobalChrome();
    if (accountPlan === 'lifetime') {
      closeOverlay('upgrade-modal-overlay');
      showToast('Lifetime Pro confirmed! Unlimited quote storage is now active.');
    } else {
      showToast('Still on Free plan — if you just paid, wait a few seconds and try again.');
    }
  } catch (err) {
    showToast(err.message || 'Could not refresh plan status');
  }
}

// ---------- CUSTOMER QUOTE MODAL ----------

function openCustomerQuoteModal(job) {
  modalQuoteJob = cloneJob(job);
  const s = state.settings;
  const snap = modalQuoteJob.snapshot;
  const est = calculateEstimate(modalQuoteJob.estimate, snap);
  const curr = snap.currency;

  const bizName = (s.businessName || '').trim() || 'Service Estimate';
  const contactParts = [s.businessPhone, s.businessEmail].map((x) => (x || '').trim()).filter(Boolean);
  const hasBranding = Boolean((s.businessName || '').trim() || contactParts.length);

  const quoteDate = formatDateISO(modalQuoteJob.createdAt || todayISO());
  const validity = (s.quoteValidity || '').trim();
  const footerNote = (s.quoteFooterNote || '').trim();
  const hasPrice = est.quotedPrice !== null && est.quotedPrice > 0;
  const hasTax = est.taxRate > 0 && hasPrice;

  $('quote-modal-warning').hidden = hasPrice;
  $('quote-branding-hint').hidden = hasBranding;
  let inIframe = false;
  try {
    inIframe = window.self !== window.top;
  } catch {
    inIframe = true;
  }
  $('quote-sandbox-hint').hidden = !inIframe;
  $('quote-copy-fallback').hidden = true;
  $('btn-copy-quote').disabled = !hasPrice;
  $('btn-print-quote').disabled = !hasPrice;
  $('btn-download-pdf').disabled = !hasPrice;

  $('customer-quote-sheet').innerHTML = `
    <div class="quote-sheet-top">
      <div>
        <h3 class="quote-biz-name">${escapeHtml(bizName)}</h3>
        ${contactParts.length ? `<p class="quote-biz-contact">${escapeHtml(contactParts.join(' · '))}</p>` : ''}
      </div>
      <div class="quote-meta">
        <strong>Customer Quote</strong>
        <div>Date: ${escapeHtml(quoteDate)}</div>
        ${validity ? `<div>${escapeHtml(validity)}</div>` : ''}
      </div>
    </div>

    <div class="quote-details-grid">
      <div>
        <div class="quote-detail-label">Prepared For</div>
        <div class="quote-detail-value">${escapeHtml(modalQuoteJob.customerName || 'Valued Customer')}</div>
      </div>
      <div>
        <div class="quote-detail-label">Service</div>
        <div class="quote-detail-value">${escapeHtml(modalQuoteJob.serviceType || 'Service Job')}</div>
      </div>
      ${
        (modalQuoteJob.notes || '').trim()
          ? `<div style="grid-column: 1 / -1">
              <div class="quote-detail-label">Scope &amp; Notes</div>
              <div class="quote-detail-value quote-notes-text">${escapeHtml(modalQuoteJob.notes.trim())}</div>
            </div>`
          : ''
      }
    </div>

    <div class="quote-totals-box tabular">
      ${
        hasTax
          ? `
            <div class="quote-total-row">
              <span>Quoted service price (excl. tax)</span>
              <span>${formatCurrency(est.quotedPrice, curr)}</span>
            </div>
            <div class="quote-total-row">
              <span>Estimated tax (${formatTaxPercent(est.taxRate)})</span>
              <span>${formatCurrency(est.taxAmount, curr)}</span>
            </div>
            <div class="quote-total-row grand">
              <span>Total Quote (incl. tax)</span>
              <span>${formatCurrency(est.quotedPriceInclTax, curr)}</span>
            </div>
          `
          : `
            <div class="quote-total-row grand" style="border-top:none;margin-top:0;padding-top:0">
              <span>Quoted Price</span>
              <span>${hasPrice ? formatCurrency(est.quotedPrice, curr) : 'TBD'}</span>
            </div>
            <div class="field-hint" style="margin-top:0.35rem">Price excludes separately charged sales tax where applicable.</div>
          `
      }
    </div>

    ${footerNote ? `<p class="quote-footer-note">${escapeHtml(footerNote)}</p>` : ''}
  `;

  openOverlay('quote-modal-overlay');
}

function buildPlainTextQuote(job) {
  const s = state.settings;
  const snap = job.snapshot;
  const est = calculateEstimate(job.estimate, snap);
  const curr = snap.currency;
  const lines = [];

  if (s.businessName) lines.push(s.businessName.toUpperCase());
  lines.push(`Quote for: ${job.customerName || 'Valued Customer'}`);
  if (job.serviceType) lines.push(`Service: ${job.serviceType}`);
  lines.push(`Date: ${formatDateISO(job.createdAt || todayISO())}`);
  if ((job.notes || '').trim()) lines.push(`Scope: ${job.notes.trim()}`);
  lines.push('');

  if (est.taxRate > 0 && est.quotedPrice !== null) {
    lines.push(`Subtotal (excl. tax): ${formatCurrency(est.quotedPrice, curr)}`);
    lines.push(`Tax (${formatTaxPercent(est.taxRate)}): ${formatCurrency(est.taxAmount, curr)}`);
    lines.push(`Total: ${formatCurrency(est.quotedPriceInclTax, curr)}`);
  } else {
    lines.push(`Quoted Price (excl. tax): ${formatCurrency(est.quotedPrice, curr)}`);
  }

  if (s.quoteValidity) lines.push(s.quoteValidity);
  if (s.quoteFooterNote) {
    lines.push('');
    lines.push(s.quoteFooterNote);
  }
  const contact = [s.businessPhone, s.businessEmail].filter(Boolean).join(' | ');
  if (contact) lines.push(contact);

  return lines.join('\n');
}

// ---------- SETTINGS DRAWER ----------

function updateSettingsCurrencySymbols(currencyCode) {
  const sym = getCurrencySymbol(currencyCode);
  document.querySelectorAll('.js-settings-currency').forEach((el) => {
    el.textContent = sym;
  });
}

function populateSettingsForm(source = state.settings) {
  const currSel = $('s-currency');
  currSel.innerHTML = SUPPORTED_CURRENCIES.map(
    (c) => `<option value="${c.code}">${escapeHtml(c.label)}</option>`
  ).join('');

  setInputValue('s-labour-rate', source.labourRate);
  setInputValue('s-target-margin', Number((source.targetMargin * 100).toFixed(1)));
  setInputValue('s-overhead', source.overheadPerJob);
  setInputValue('s-travel-rate', source.travelRate);
  setInputValue('s-tax-rate', Number((source.taxRate * 100).toFixed(3)));
  currSel.value = source.currency;
  updateSettingsCurrencySymbols(source.currency);
  $('s-distance-unit').value = source.distanceUnit;
  $('s-unit-hint').textContent = source.distanceUnit;

  setInputValue('s-biz-name', source.businessName);
  setInputValue('s-biz-phone', source.businessPhone);
  setInputValue('s-biz-email', source.businessEmail);
  setInputValue('s-quote-validity', source.quoteValidity);
  setInputValue('s-quote-footer', source.quoteFooterNote);
}

async function saveSettingsFromForm() {
  const rawMarginPct = parseNum($('s-target-margin').value);
  const rawTaxPct = parseNum($('s-tax-rate').value);
  const rawLabour = parseNum($('s-labour-rate').value);
  const rawOverhead = parseNum($('s-overhead').value);
  const rawTravel = parseNum($('s-travel-rate').value);

  if (
    (rawLabour !== null && rawLabour < 0) ||
    (rawOverhead !== null && rawOverhead < 0) ||
    (rawTravel !== null && rawTravel < 0) ||
    (rawMarginPct !== null && rawMarginPct < 0) ||
    (rawTaxPct !== null && rawTaxPct < 0)
  ) {
    showToast('Settings values cannot be negative');
    return;
  }

  const clampedNotes = [];
  if (rawMarginPct !== null && rawMarginPct > 95) clampedNotes.push('target margin capped at 95%');
  if (rawTaxPct !== null && rawTaxPct > 50) clampedNotes.push('tax rate capped at 50%');

  const next = {
    labourRate: Math.max(0, rawLabour ?? DEFAULT_SETTINGS.labourRate),
    targetMargin: clampMargin((rawMarginPct ?? 40) / 100),
    overheadPerJob: Math.max(0, rawOverhead ?? DEFAULT_SETTINGS.overheadPerJob),
    travelRate: Math.max(0, rawTravel ?? DEFAULT_SETTINGS.travelRate),
    taxRate: Math.max(0, Math.min(0.5, (rawTaxPct ?? 0) / 100)),
    currency: $('s-currency').value || 'USD',
    distanceUnit: $('s-distance-unit').value === 'mi' ? 'mi' : 'km',
    businessName: $('s-biz-name').value.trim(),
    businessPhone: $('s-biz-phone').value.trim(),
    businessEmail: $('s-biz-email').value.trim(),
    quoteValidity: $('s-quote-validity').value.trim(),
    quoteFooterNote: $('s-quote-footer').value.trim(),
  };

  try {
    state.settings = currentUser ? await dataService.saveSettings(next) : next;
  } catch (err) {
    showToast(err.message || 'Could not save settings');
    return;
  }

  if (!editingQuoteId) {
    quoteDraft.snapshot = {
      targetMargin: state.settings.targetMargin,
      taxRate: state.settings.taxRate,
      currency: state.settings.currency,
      distanceUnit: state.settings.distanceUnit,
      defaultLabourRate: state.settings.labourRate,
      defaultTravelRate: state.settings.travelRate,
      defaultOverhead: state.settings.overheadPerJob,
    };
    if (!quoteDraft.estimate.labourRateOverridden) quoteDraft.estimate.labourRate = state.settings.labourRate;
    if (!quoteDraft.estimate.travelRateOverridden) quoteDraft.estimate.travelRate = state.settings.travelRate;
    if (!quoteDraft.estimate.overheadOverridden) quoteDraft.estimate.overhead = state.settings.overheadPerJob;
    renderQuoteForm();
    renderQuoteSummary();
  }

  if (activeView === 'log') renderJobLog();
  closeOverlay('settings-overlay');
  showToast(
    clampedNotes.length
      ? `Settings saved (${clampedNotes.join(', ')})`
      : currentUser
      ? 'Business settings saved to your account'
      : 'Business settings updated for this guest session'
  );
}

// ---------- OVERLAY HELPERS ----------

function openOverlay(id) {
  const el = $(id);
  if (!el) return;
  el.classList.add('is-open');
  el.setAttribute('aria-hidden', 'false');
}

function closeOverlay(id) {
  const el = $(id);
  if (!el) return;
  el.classList.remove('is-open');
  el.setAttribute('aria-hidden', 'true');
}

// ---------- EVENT WIRING ----------

function initEvents() {
  // Forms
  $('quote-form').addEventListener('submit', (e) => {
    e.preventDefault();
    saveCurrentQuote();
  });
  $('actuals-form').addEventListener('submit', (e) => {
    e.preventDefault();
    saveActualsForSelectedJob();
  });
  $('settings-form').addEventListener('submit', (e) => {
    e.preventDefault();
    saveSettingsFromForm();
  });
  $('auth-form').addEventListener('submit', handleAuthSubmit);

  // Header account & auth controls
  $('btn-header-signin').addEventListener('click', () => {
    pendingPostAuthAction = null;
    openAuthModal('signin');
  });
  $('btn-header-signup').addEventListener('click', () => {
    pendingPostAuthAction = null;
    openAuthModal('signup');
  });
  $('btn-banner-signup').addEventListener('click', () => {
    pendingPostAuthAction = null;
    openAuthModal('signup');
  });
  $('btn-header-plan').addEventListener('click', () => openUpgradeModal({ triggeredByLimit: false }));
  $('btn-header-signout').addEventListener('click', async () => {
    await dataService.signOut();
    enterGuestWorkspace();
    showToast('Signed out');
  });

  // Auth modal tabs & links
  $('auth-tab-signup').addEventListener('click', () => setAuthMode('signup'));
  $('auth-tab-signin').addEventListener('click', () => setAuthMode('signin'));
  $('btn-auth-forgot').addEventListener('click', () => setAuthMode('reset'));
  $('btn-auth-back-signin').addEventListener('click', () => setAuthMode('signin'));
  $('btn-close-auth-modal').addEventListener('click', () => {
    pendingPostAuthAction = null;
    closeOverlay('auth-modal-overlay');
  });

  // Upgrade modal controls
  $('btn-close-upgrade-modal').addEventListener('click', () => closeOverlay('upgrade-modal-overlay'));
  $('btn-upgrade-checkout').addEventListener('click', handleUpgradeCheckout);
  $('btn-upgrade-refresh').addEventListener('click', refreshPlanStatus);

  // Primary navigation tabs
  document.querySelectorAll('.nav-tab').forEach((btn) => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // Demo banner
  $('btn-clear-demo').addEventListener('click', () => {
    state.jobs = state.jobs.filter((j) => !j.isDemo);
    state.demoDismissed = true;
    if (editingQuoteId && !state.jobs.some((j) => j.id === editingQuoteId)) {
      loadJobIntoQuoteEditor(null);
    }
    if (selectedActualJobId && !state.jobs.some((j) => j.id === selectedActualJobId)) {
      selectedActualJobId = null;
      actualDraft = null;
    }
    renderGlobalChrome();
    switchView(activeView);
    showToast('Demo jobs cleared');
  });

  $('btn-dismiss-demo').addEventListener('click', () => {
    state.demoDismissed = true;
    renderGlobalChrome();
  });

  // View 1: Quote events
  $('quote-job-select').addEventListener('change', (e) => {
    loadJobIntoQuoteEditor(e.target.value || null);
  });

  $('btn-new-quote').addEventListener('click', () => {
    loadJobIntoQuoteEditor(null);
    $('q-customer').focus();
  });

  $('btn-duplicate-quote').addEventListener('click', () => {
    readQuoteFormIntoDraft();
    const copy = cloneJob(quoteDraft);
    copy.id = null;
    copy.isDemo = false;
    copy.status = 'quoted';
    copy.completedDate = null;
    copy.actual = null;
    copy.createdAt = todayISO();
    copy.customerName = copy.customerName ? `${copy.customerName} (Copy)` : 'Copied quote';
    editingQuoteId = null;
    quoteDraft = copy;
    renderQuoteSelector();
    renderQuoteForm();
    renderQuoteSummary();
    showToast('Duplicated into a new draft — click Save Quote to keep it');
  });

  $('quote-form').addEventListener('input', () => {
    readQuoteFormIntoDraft();
    renderQuoteSummary();
  });

  $('btn-apply-recommended').addEventListener('click', () => {
    readQuoteFormIntoDraft();
    const res = calculateEstimate(quoteDraft.estimate, quoteDraft.snapshot);
    if (res.recommendedPrice !== null && !res.hasNegativeInput) {
      quoteDraft.estimate.quotedPrice = res.recommendedPrice;
      setInputValue('q-price', res.recommendedPrice.toFixed(2));
      validateNonNegativeForm('quote-form', 'quote-validation-alert');
      renderQuoteSummary();
      showToast('Quoted price set to recommended price');
    }
  });

  $('pill-q-labour-rate').addEventListener('click', () => {
    quoteDraft.estimate.labourRate = quoteDraft.snapshot.defaultLabourRate;
    quoteDraft.estimate.labourRateOverridden = false;
    setInputValue('q-labour-rate', quoteDraft.estimate.labourRate);
    updateOverridePill('pill-q-labour-rate', false);
    validateNonNegativeForm('quote-form', 'quote-validation-alert');
    renderQuoteSummary();
  });

  $('pill-q-travel-rate').addEventListener('click', () => {
    quoteDraft.estimate.travelRate = quoteDraft.snapshot.defaultTravelRate;
    quoteDraft.estimate.travelRateOverridden = false;
    setInputValue('q-travel-rate', quoteDraft.estimate.travelRate);
    updateOverridePill('pill-q-travel-rate', false);
    validateNonNegativeForm('quote-form', 'quote-validation-alert');
    renderQuoteSummary();
  });

  $('pill-q-overhead').addEventListener('click', () => {
    quoteDraft.estimate.overhead = quoteDraft.snapshot.defaultOverhead;
    quoteDraft.estimate.overheadOverridden = false;
    setInputValue('q-overhead', quoteDraft.estimate.overhead);
    updateOverridePill('pill-q-overhead', false);
    validateNonNegativeForm('quote-form', 'quote-validation-alert');
    renderQuoteSummary();
  });

  $('btn-save-quote').addEventListener('click', () => {
    saveCurrentQuote();
  });

  $('btn-preview-quote').addEventListener('click', () => {
    readQuoteFormIntoDraft();
    openCustomerQuoteModal(quoteDraft);
  });

  $('btn-go-actuals').addEventListener('click', async () => {
    const id = await saveCurrentQuote({ silent: true, goToActualsAfter: true });
    if (!id) return;
    selectedActualJobId = id;
    actualDraft = null;
    switchView('actuals');
  });

  // View 2: Actuals events
  $('actual-job-select').addEventListener('change', (e) => {
    selectedActualJobId = e.target.value || null;
    actualDraft = null;
    renderActualsView();
  });

  $('actuals-form').addEventListener('input', () => {
    const job = state.jobs.find((j) => j.id === selectedActualJobId);
    if (!job) return;
    readActualsFormIntoDraft();
    renderActualsSummary(job);
  });

  $('btn-reset-actuals-to-est').addEventListener('click', () => {
    const job = state.jobs.find((j) => j.id === selectedActualJobId);
    if (!job) return;
    actualDraft = {
      jobId: job.id,
      completedDate: actualDraft?.completedDate || todayISO(),
      values: prefillActualFromEstimate(job),
      wasPrefilled: true,
    };
    renderActualsView();
    showToast('Actual fields reset to original estimate');
  });

  $('btn-save-actuals').addEventListener('click', saveActualsForSelectedJob);
  $('btn-actuals-to-log').addEventListener('click', () => switchView('log'));

  $('btn-actuals-edit-quote').addEventListener('click', () => {
    if (selectedActualJobId) loadJobIntoQuoteEditor(selectedActualJobId);
    switchView('quote');
  });

  $('btn-actuals-start-quote').addEventListener('click', () => {
    loadJobIntoQuoteEditor(null);
    switchView('quote');
  });

  // View 3: Job Log events
  $('log-search').addEventListener('input', renderJobLog);
  $('log-status-filter').addEventListener('change', renderJobLog);
  $('log-service-filter').addEventListener('change', renderJobLog);
  $('log-currency-filter').addEventListener('change', renderJobLog);

  $('btn-new-from-log').addEventListener('click', () => {
    loadJobIntoQuoteEditor(null);
    switchView('quote');
  });
  $('btn-empty-new-job').addEventListener('click', () => {
    loadJobIntoQuoteEditor(null);
    switchView('quote');
  });

  $('log-tbody').addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const { action, id } = btn.dataset;
    const job = state.jobs.find((j) => j.id === id);
    if (!job) return;

    if (action === 'edit-quote') {
      loadJobIntoQuoteEditor(id);
      switchView('quote');
    } else if (action === 'record-actuals') {
      selectedActualJobId = id;
      actualDraft = null;
      switchView('actuals');
    } else if (action === 'customer-quote') {
      openCustomerQuoteModal(job);
    } else if (action === 'delete-job') {
      const ok = window.confirm(`Delete "${job.customerName || 'this job'}"? This cannot be undone.`);
      if (!ok) return;
      try {
        if (currentUser) await dataService.deleteJob(id);
        state.jobs = state.jobs.filter((j) => j.id !== id);
        if (editingQuoteId === id) loadJobIntoQuoteEditor(null);
        if (selectedActualJobId === id) {
          selectedActualJobId = null;
          actualDraft = null;
        }
        renderGlobalChrome();
        renderJobLog();
        showToast('Job deleted');
      } catch (err) {
        showToast(err.message || 'Could not delete job');
      }
    }
  });

  // Export & Backup
  $('btn-export-csv').addEventListener('click', () => {
    const csv = exportJobsCSV(state.jobs, true);
    triggerDownload(csv, `smallbiz-job-log-${todayISO()}.csv`, 'text/csv;charset=utf-8');
    showToast('Exported Job Log CSV');
  });

  $('btn-export-json').addEventListener('click', () => {
    const json = exportBackupJSON(state);
    triggerDownload(json, `smallbiz-pricing-backup-${todayISO()}.json`, 'application/json');
    showToast('Downloaded JSON backup');
  });

  $('btn-import-json').addEventListener('click', () => {
    $('input-import-json').value = '';
    $('input-import-json').click();
  });

  $('input-import-json').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const restored = parseBackupJSON(text);
      if (!currentUser) {
        state = { settings: restored.settings, jobs: restored.jobs, demoDismissed: true };
        loadJobIntoQuoteEditor(null);
        selectedActualJobId = null;
        actualDraft = null;
        renderGlobalChrome();
        switchView('log');
        showToast(`Loaded ${state.jobs.length} jobs in guest preview`);
        return;
      }

      // Signed-in restore: save settings & import jobs through quota-enforced endpoint
      state.settings = await dataService.saveSettings(restored.settings);
      let imported = 0;
      let hitLimit = false;
      for (const j of restored.jobs) {
        try {
          const res = await dataService.createJobWithQuota(j);
          state.jobs.unshift(res.job);
          accountUsage = res.usage;
          imported += 1;
        } catch (err) {
          if (err.code === 'QUOTA_EXCEEDED') {
            hitLimit = true;
            break;
          }
          throw err;
        }
      }
      renderGlobalChrome();
      switchView('log');
      if (hitLimit) {
        showToast(`Imported ${imported} jobs before hitting the free monthly limit`);
        openUpgradeModal({ triggeredByLimit: true });
      } else {
        showToast(`Imported ${imported} jobs into your account`);
      }
    } catch (err) {
      showToast(err.message || 'Could not restore backup file');
    }
  });

  // Settings drawer
  $('btn-open-settings').addEventListener('click', () => {
    populateSettingsForm(state.settings);
    openOverlay('settings-overlay');
  });
  $('btn-close-settings').addEventListener('click', () => closeOverlay('settings-overlay'));
  $('s-currency').addEventListener('change', (e) => updateSettingsCurrencySymbols(e.target.value));
  $('s-distance-unit').addEventListener('change', (e) => {
    $('s-unit-hint').textContent = e.target.value;
  });
  $('btn-save-settings').addEventListener('click', saveSettingsFromForm);
  $('btn-reset-settings').addEventListener('click', () => {
    populateSettingsForm(DEFAULT_SETTINGS);
    showToast('Workbook defaults loaded — click Save Settings to apply');
  });

  // Quick Start drawer
  $('btn-open-guide').addEventListener('click', () => openOverlay('guide-overlay'));
  $('btn-close-guide').addEventListener('click', () => closeOverlay('guide-overlay'));
  $('btn-guide-done').addEventListener('click', () => closeOverlay('guide-overlay'));

  // Customer quote modal
  $('btn-close-quote-modal').addEventListener('click', () => closeOverlay('quote-modal-overlay'));
  $('btn-copy-quote').addEventListener('click', async () => {
    if (!modalQuoteJob) return;
    const text = buildPlainTextQuote(modalQuoteJob);
    try {
      await navigator.clipboard.writeText(text);
      showToast('Quote copied to clipboard');
      return;
    } catch {
      // fall through to execCommand / selectable textarea
    }
    let copied = false;
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      copied = Boolean(document.execCommand('copy'));
      ta.remove();
    } catch {
      copied = false;
    }
    if (copied) {
      showToast('Quote copied to clipboard');
    } else {
      $('quote-copy-fallback').hidden = false;
      $('quote-copy-textarea').value = text;
      $('quote-copy-textarea').focus();
      $('quote-copy-textarea').select();
      showToast('Select and press Ctrl+C / Cmd+C to copy');
    }
  });

  $('btn-download-pdf').addEventListener('click', () => {
    if (!modalQuoteJob) return;
    try {
      downloadCustomerQuotePdf(modalQuoteJob, state.settings);
      showToast('Downloaded customer quote PDF');
    } catch (err) {
      showToast(err.message || 'Could not generate PDF');
    }
  });

  $('btn-print-quote').addEventListener('click', () => {
    const cleanup = () => document.body.classList.remove('printing-quote');
    window.addEventListener('afterprint', cleanup, { once: true });
    document.body.classList.add('printing-quote');
    try {
      window.print();
    } catch {
      cleanup();
      showToast('Print dialog blocked here — use Download PDF instead');
    }
  });

  // Backdrop & Escape closes overlays
  [
    'settings-overlay',
    'guide-overlay',
    'quote-modal-overlay',
    'auth-modal-overlay',
    'upgrade-modal-overlay',
  ].forEach((id) => {
    $(id).addEventListener('click', (e) => {
      if (e.target.id === id) {
        if (id === 'auth-modal-overlay') pendingPostAuthAction = null;
        closeOverlay(id);
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      pendingPostAuthAction = null;
      [
        'settings-overlay',
        'guide-overlay',
        'quote-modal-overlay',
        'auth-modal-overlay',
        'upgrade-modal-overlay',
      ].forEach(closeOverlay);
    }
  });
}

// ---------- BOOTSTRAP ----------

async function init() {
  applyConfigLabels();
  initEvents();

  try {
    const { user } = await dataService.getSession();
    if (user) {
      await loadAuthenticatedWorkspace();
      const params = new URLSearchParams(window.location.search);
      if (params.get('upgraded') === '1' && accountPlan === 'lifetime') {
        showToast('Welcome to Lifetime Pro! Unlimited quotes are now unlocked.');
      }
      return;
    }
  } catch (err) {
    showToast(err.message || 'Could not restore session — continuing in guest mode');
  }

  enterGuestWorkspace();
}

init();
