/**
 * SmallBiz Job Profit & Pricing Calculator — Pure Calculation Engine
 * Faithful to SmallBiz_Job_Profit_and_Pricing_Calculator.xlsx formulas
 * with sign-symmetric rounding, conservative cent ceiling on recommended price,
 * negative-input detection, and multi-currency summary support.
 */

export const MAX_TARGET_MARGIN = 0.95;
export const MIN_TARGET_MARGIN = 0;

export const JOB_STATUS_RESULT = {
  CHECK_INPUTS: 'check_inputs',
  LOSS: 'loss',
  BELOW_TARGET: 'below_target',
  ON_TARGET: 'on_target',
};

/**
 * Safely parse a numeric value. Returns null if empty/blank/invalid.
 */
export function parseNum(value) {
  if (value === '' || value === null || value === undefined) return null;
  const n = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(n) ? n : null;
}

/**
 * Clamp target margin to valid workbook range [0, 0.95].
 */
export function clampMargin(margin) {
  const n = parseNum(margin);
  if (n === null) return 0;
  return Math.min(MAX_TARGET_MARGIN, Math.max(MIN_TARGET_MARGIN, n));
}

/**
 * Sign-symmetric rounding to 2 decimal places without -0.
 */
export function round2(n) {
  if (!Number.isFinite(n)) return n;
  const sign = n < 0 ? -1 : 1;
  const rounded = (sign * Math.round((Math.abs(n) + Number.EPSILON) * 100)) / 100;
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Round UP to nearest cent (with tiny floating-point tolerance) so that charging
 * the recommended price always achieves at least the target profit margin.
 */
export function ceil2(n) {
  if (!Number.isFinite(n)) return n;
  if (n <= 0) return 0;
  const scaled = n * 100;
  const nearestInt = Math.round(scaled);
  if (Math.abs(scaled - nearestInt) < 1e-9) {
    return nearestInt / 100;
  }
  return Math.ceil(scaled) / 100;
}

/**
 * Compute cost breakdown and totals from a cost input object.
 * Matches PRICE A JOB!B17 and JOB RESULTS!B16:
 *   labourHours * labourRate + materials + travelDistance * travelRate + equipment + subcontractor + otherDirect + overhead
 */
export function calculateCostBreakdown(inputs = {}) {
  const rawFields = [
    inputs.labourHours,
    inputs.labourRate,
    inputs.materials,
    inputs.travelDistance,
    inputs.travelRate,
    inputs.equipment,
    inputs.subcontractor,
    inputs.otherDirect,
    inputs.overhead,
  ];

  const hasNegativeCostInput = rawFields.some((v) => {
    const n = parseNum(v);
    return n !== null && n < 0;
  });

  const labourHours = Math.max(0, parseNum(inputs.labourHours) ?? 0);
  const labourRate = Math.max(0, parseNum(inputs.labourRate) ?? 0);
  const materials = Math.max(0, parseNum(inputs.materials) ?? 0);
  const travelDistance = Math.max(0, parseNum(inputs.travelDistance) ?? 0);
  const travelRate = Math.max(0, parseNum(inputs.travelRate) ?? 0);
  const equipment = Math.max(0, parseNum(inputs.equipment) ?? 0);
  const subcontractor = Math.max(0, parseNum(inputs.subcontractor) ?? 0);
  const otherDirect = Math.max(0, parseNum(inputs.otherDirect) ?? 0);
  const overhead = Math.max(0, parseNum(inputs.overhead) ?? 0);

  const labourCost = round2(labourHours * labourRate);
  const travelCost = round2(travelDistance * travelRate);
  const directOtherCost = round2(equipment + subcontractor + otherDirect);
  const totalCost = round2(
    labourCost + materials + travelCost + equipment + subcontractor + otherDirect + overhead
  );

  const hasAnyCostInput = rawFields.some((v) => parseNum(v) !== null);

  return {
    hasAnyCostInput,
    hasNegativeCostInput,
    labourCost,
    materials: round2(materials),
    travelCost,
    equipment: round2(equipment),
    subcontractor: round2(subcontractor),
    otherDirect: round2(otherDirect),
    directOtherCost,
    overhead: round2(overhead),
    totalCost: hasAnyCostInput ? totalCost : null,
  };
}

/**
 * Evaluate a job quote (mirrors PRICE A JOB tab).
 */
export function calculateEstimate(estimate = {}, snapshot = {}) {
  const breakdown = calculateCostBreakdown(estimate);
  const totalCost = breakdown.totalCost;
  const rawQuotedPrice = parseNum(estimate.quotedPrice);
  const hasNegativePrice = rawQuotedPrice !== null && rawQuotedPrice < 0;
  const hasNegativeInput = hasNegativePrice || breakdown.hasNegativeCostInput;
  const quotedPrice = hasNegativePrice ? null : rawQuotedPrice;

  const targetMargin = parseNum(snapshot.targetMargin);
  const taxRate = Math.max(0, parseNum(snapshot.taxRate) ?? 0);

  // RECOMMENDED PRICE: IF(OR(B17="",B18>=1,B18<0),"",B17/(1-B18))
  // Rounded UP to nearest cent so using Recommended Price always meets >= targetMargin.
  const validMargin = targetMargin !== null && targetMargin >= 0 && targetMargin < 1;
  const recommendedPrice =
    totalCost !== null && validMargin ? ceil2(totalCost / (1 - targetMargin)) : null;

  // EXPECTED PROFIT: IF(OR(B7="",B17=""),"",B7-B17)
  const expectedProfit =
    quotedPrice !== null && totalCost !== null ? round2(quotedPrice - totalCost) : null;

  // EXPECTED MARGIN: IF(OR(B7="",B7<=0,B20=""),"",B20/B7)
  const expectedMargin =
    quotedPrice !== null && quotedPrice > 0 && expectedProfit !== null
      ? expectedProfit / quotedPrice
      : null;

  // Difference from recommended: B7 - B19
  const diffFromRecommended =
    quotedPrice !== null && recommendedPrice !== null
      ? round2(quotedPrice - recommendedPrice)
      : null;

  // Quoted price incl. tax: B7 * (1 + taxRate)
  const quotedPriceInclTax =
    quotedPrice !== null && quotedPrice >= 0 ? round2(quotedPrice * (1 + taxRate)) : null;

  const taxAmount =
    quotedPrice !== null && quotedPrice >= 0 ? round2(quotedPrice * taxRate) : null;

  // Margin vs goal (% points): B21 - B18
  const marginVsGoal =
    expectedMargin !== null && validMargin ? expectedMargin - targetMargin : null;

  // Status:
  // Invalid/negative inputs or blank price/recommended => Check inputs
  // quotedPrice < totalCost => Below cost (Loss)
  // quotedPrice < recommendedPrice (and margin < target) => Below target
  // Otherwise => Meets target
  let resultCode = JOB_STATUS_RESULT.CHECK_INPUTS;
  let resultLabel = 'Check inputs';

  if (!hasNegativeInput && quotedPrice !== null && recommendedPrice !== null && totalCost !== null) {
    if (quotedPrice === 0 && totalCost === 0) {
      resultCode = JOB_STATUS_RESULT.CHECK_INPUTS;
      resultLabel = 'Check inputs';
    } else if (quotedPrice < totalCost) {
      resultCode = JOB_STATUS_RESULT.LOSS;
      resultLabel = 'Below cost';
    } else if (
      quotedPrice + 1e-9 < recommendedPrice &&
      (expectedMargin === null || expectedMargin + 1e-9 < targetMargin)
    ) {
      resultCode = JOB_STATUS_RESULT.BELOW_TARGET;
      resultLabel = 'Below target';
    } else {
      resultCode = JOB_STATUS_RESULT.ON_TARGET;
      resultLabel = 'Meets target';
    }
  }

  return {
    breakdown,
    hasNegativeInput,
    totalCost,
    targetMargin: validMargin ? targetMargin : null,
    recommendedPrice,
    quotedPrice,
    expectedProfit,
    expectedMargin,
    breakEvenPrice: totalCost,
    diffFromRecommended,
    quotedPriceInclTax,
    taxAmount,
    taxRate,
    marginVsGoal,
    resultCode,
    resultLabel,
  };
}

/**
 * Evaluate completed job actuals and variance vs. estimate (mirrors JOB RESULTS tab).
 */
export function calculateActuals(actual = null, estimate = {}, snapshot = {}) {
  const est = calculateEstimate(estimate, snapshot);
  if (!actual) {
    return {
      hasActual: false,
      hasNegativeInput: false,
      estimateMetrics: est,
      breakdown: null,
      actualPrice: null,
      actualTotalCost: null,
      actualProfit: null,
      actualMargin: null,
      actualPriceInclTax: null,
      priceVsRecommended: null,
      profitVariance: null,
      costVariance: null,
      priceVariance: null,
      marginVariance: null,
      lineVariances: null,
      resultCode: JOB_STATUS_RESULT.CHECK_INPUTS,
      resultLabel: 'Not recorded',
    };
  }

  const breakdown = calculateCostBreakdown(actual);
  const rawActualPrice = parseNum(actual.actualPrice);
  const hasNegativePrice = rawActualPrice !== null && rawActualPrice < 0;
  const hasNegativeInput = hasNegativePrice || breakdown.hasNegativeCostInput;
  const actualPrice = hasNegativePrice ? null : rawActualPrice;

  const targetMargin = est.targetMargin ?? 0;
  const taxRate = est.taxRate;

  // Always show actualTotalCost when cost inputs exist so total matches line-item breakdown
  const actualTotalCost = breakdown.totalCost;
  const actualProfit =
    actualPrice !== null && actualTotalCost !== null
      ? round2(actualPrice - actualTotalCost)
      : null;
  const actualMargin =
    actualPrice !== null && actualPrice > 0 && actualProfit !== null
      ? actualProfit / actualPrice
      : null;
  const actualPriceInclTax =
    actualPrice !== null && actualPrice >= 0 ? round2(actualPrice * (1 + taxRate)) : null;

  // PRICE VS RECOMMENDED: actualPrice - estimated recommendedPrice
  const priceVsRecommended =
    actualPrice !== null && est.recommendedPrice !== null
      ? round2(actualPrice - est.recommendedPrice)
      : null;

  // COMPARE TO ESTIMATE
  const profitVariance =
    actualProfit !== null && est.expectedProfit !== null
      ? round2(actualProfit - est.expectedProfit)
      : null;
  const costVariance =
    actualTotalCost !== null && est.totalCost !== null
      ? round2(actualTotalCost - est.totalCost)
      : null;
  const priceVariance =
    actualPrice !== null && est.quotedPrice !== null
      ? round2(actualPrice - est.quotedPrice)
      : null;
  const marginVariance =
    actualMargin !== null && est.expectedMargin !== null
      ? actualMargin - est.expectedMargin
      : null;

  // Line-by-line cost variances (positive means actual cost exceeded estimate)
  const lineVariances = [
    {
      key: 'labour',
      label: 'Labour',
      estimated: est.breakdown.labourCost,
      actual: breakdown.labourCost,
      variance: round2(breakdown.labourCost - est.breakdown.labourCost),
    },
    {
      key: 'materials',
      label: 'Materials & supplies',
      estimated: est.breakdown.materials,
      actual: breakdown.materials,
      variance: round2(breakdown.materials - est.breakdown.materials),
    },
    {
      key: 'travel',
      label: 'Travel',
      estimated: est.breakdown.travelCost,
      actual: breakdown.travelCost,
      variance: round2(breakdown.travelCost - est.breakdown.travelCost),
    },
    {
      key: 'equipment',
      label: 'Equipment / rental',
      estimated: est.breakdown.equipment,
      actual: breakdown.equipment,
      variance: round2(breakdown.equipment - est.breakdown.equipment),
    },
    {
      key: 'subcontractor',
      label: 'Subcontractor',
      estimated: est.breakdown.subcontractor,
      actual: breakdown.subcontractor,
      variance: round2(breakdown.subcontractor - est.breakdown.subcontractor),
    },
    {
      key: 'otherDirect',
      label: 'Other direct costs',
      estimated: est.breakdown.otherDirect,
      actual: breakdown.otherDirect,
      variance: round2(breakdown.otherDirect - est.breakdown.otherDirect),
    },
    {
      key: 'overhead',
      label: 'Allocated overhead',
      estimated: est.breakdown.overhead,
      actual: breakdown.overhead,
      variance: round2(breakdown.overhead - est.breakdown.overhead),
    },
  ];

  // Unified Job Log status formula:
  let resultCode = JOB_STATUS_RESULT.CHECK_INPUTS;
  let resultLabel = 'Check inputs';
  if (!hasNegativeInput && actualPrice !== null && actualProfit !== null && actualTotalCost !== null) {
    if (actualPrice === 0 && actualTotalCost === 0) {
      resultCode = JOB_STATUS_RESULT.CHECK_INPUTS;
      resultLabel = 'Check inputs';
    } else if (actualProfit < 0) {
      resultCode = JOB_STATUS_RESULT.LOSS;
      resultLabel = 'Loss';
    } else if (actualMargin === null || actualMargin + 1e-9 < targetMargin) {
      resultCode = JOB_STATUS_RESULT.BELOW_TARGET;
      resultLabel = 'Below target';
    } else {
      resultCode = JOB_STATUS_RESULT.ON_TARGET;
      resultLabel = 'On target';
    }
  }

  return {
    hasActual: true,
    hasNegativeInput,
    estimateMetrics: est,
    breakdown,
    actualPrice,
    actualTotalCost,
    actualProfit,
    actualMargin,
    actualPriceInclTax,
    priceVsRecommended,
    profitVariance,
    costVariance,
    priceVariance,
    marginVariance,
    lineVariances,
    resultCode,
    resultLabel,
  };
}

/**
 * Aggregate completed jobs summary (mirrors JOB LOG rows 208-213).
 * Tracks distinct currencies so mixed-currency ledgers are flagged instead of silently summed.
 */
export function calculateLogSummary(jobs = [], filterCurrency = null) {
  const allCompleted = jobs.filter((j) => j.status === 'completed' && j.actual);
  const currencies = Array.from(
    new Set(allCompleted.map((j) => j.snapshot?.currency || 'USD'))
  ).sort();

  const completed =
    filterCurrency && filterCurrency !== 'all'
      ? allCompleted.filter((j) => (j.snapshot?.currency || 'USD') === filterCurrency)
      : allCompleted;

  const activeCurrencies = Array.from(
    new Set(completed.map((j) => j.snapshot?.currency || 'USD'))
  );
  const hasMixedCurrencies = activeCurrencies.length > 1;
  const displayCurrency = activeCurrencies.length === 1 ? activeCurrencies[0] : null;

  let revenue = 0;
  let totalCost = 0;
  let totalProfit = 0;
  let lossMakingCount = 0;
  let onTargetCount = 0;
  let belowTargetCount = 0;

  for (const job of completed) {
    const res = calculateActuals(job.actual, job.estimate, job.snapshot);
    if (res.actualPrice !== null) revenue += res.actualPrice;
    if (res.actualTotalCost !== null) totalCost += res.actualTotalCost;
    if (res.actualProfit !== null) {
      totalProfit += res.actualProfit;
      if (res.actualProfit < 0) lossMakingCount += 1;
    }
    if (res.resultCode === JOB_STATUS_RESULT.ON_TARGET) onTargetCount += 1;
    else if (res.resultCode === JOB_STATUS_RESULT.BELOW_TARGET) belowTargetCount += 1;
  }

  revenue = round2(revenue);
  totalCost = round2(totalCost);
  totalProfit = round2(totalProfit);
  const overallMargin = !hasMixedCurrencies && revenue > 0 ? totalProfit / revenue : null;

  return {
    completedCount: completed.length,
    quotedCount: jobs.filter((j) => j.status === 'quoted').length,
    currencies,
    hasMixedCurrencies,
    displayCurrency,
    revenue: hasMixedCurrencies ? null : revenue,
    totalCost: hasMixedCurrencies ? null : totalCost,
    totalProfit: hasMixedCurrencies ? null : totalProfit,
    overallMargin,
    lossMakingCount,
    onTargetCount,
    belowTargetCount,
  };
}
