import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

function stripModuleSyntax(code) {
  return code
    .replace(/^import\s+[\s\S]*?from\s+['"][^'"]+['"];?\s*$/gm, '')
    .replace(/^export\s+(?=(const|let|var|function|class)\b)/gm, '');
}

export function buildSingleFileHtml() {
  const html = read('index.html');
  const tokensCss = read('styles/tokens.css');
  const appCss = read('styles/app.css');
  const printCss = read('styles/print.css');

  const jsOrder = [
    'js/config.js',
    'js/calculator.js',
    'js/format.js',
    'js/demoData.js',
    'js/storage.js',
    'js/providers/localMultiUserProvider.js',
    'js/providers/supabaseProvider.js',
    'js/dataService.js',
    'js/pdfQuote.js',
    'js/app.js',
  ];

  const bundledJs =
    '(function() {\n"use strict";\n' +
    jsOrder
      .map((file) => `/* --- ${file} --- */\n${stripModuleSyntax(read(file))}`)
      .join('\n\n') +
    '\n})();';

  let out = html
    .replace(
      /<link rel="stylesheet" href="\.\/styles\/tokens\.css"\s*\/?>\s*<link rel="stylesheet" href="\.\/styles\/app\.css"\s*\/?>\s*<link rel="stylesheet" href="\.\/styles\/print\.css" media="print"\s*\/?>/,
      () => `<style>\n${tokensCss}\n${appCss}\n${printCss}\n</style>`
    )
    .replace(
      /<script type="module" src="\.\/js\/app\.js"><\/script>/,
      () => `<script>\n${bundledJs}\n</script>`
    );

  return out;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const outPath = process.argv[2] || path.join(root, 'dist', 'smallbiz-pricing-calculator.html');
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, buildSingleFileHtml(), 'utf8');
  console.log(`Bundled single-file HTML to ${outPath}`);
}
